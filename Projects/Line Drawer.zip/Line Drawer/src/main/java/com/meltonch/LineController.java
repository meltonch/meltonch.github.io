package com.meltonch;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.PixelWriter;
import javafx.scene.paint.Color;
import javafx.event.ActionEvent;
import com.meltonch.EndPoints;

public class LineController {

	private static final int IMAGE_WIDTH = 1180, IMAGE_HEIGHT = 845;

	@FXML TextField numField;
	@FXML TextField dashField;
	@FXML Button drawButton;
	@FXML Canvas canvas;
	GraphicsContext gc;
	PixelWriter pw;
	int numLines;
	int dashLength = 0;
	boolean drawDash = true;
	int[] start, end;
	long startTime, endTime, duration;
	int x, y, x0, y0 = 0;
	int err, inc1, inc2;
	double slope;
	boolean simple = true;
	boolean bresenham = false;
	EndPoints coSet;
	EndPoints[] endpoints;
	
	@FXML public void handleSimpleButtonAction(ActionEvent event) {
		simple = true;
		bresenham = false;
		
		System.out.println("");
		System.out.println("Simple: " + simple);
		System.out.println("Bresenham: " + bresenham);
		System.out.println("");
	}
	
	@FXML public void handleBresenhamButtonAction(ActionEvent event) {
		simple = false;
		bresenham = true;
		
		System.out.println("");
		System.out.println("Simple: " + simple);
		System.out.println("Bresenham: " + bresenham);
		System.out.println("");
	}
	
	@FXML public void handleDashFieldAction(ActionEvent event) {
		dashLength = Integer.parseInt(dashField.getText());
		System.out.println("Dash Length: " + dashLength);
	}
	
	@FXML public void handleDrawButtonAction(ActionEvent event) {
	
		numLines = Integer.parseInt(numField.getText());
		System.out.println("numLines: " + numLines);
		
		endpoints = new EndPoints[numLines];
		
		for(int i = 0; i < numLines; i++) {
			endpoints[i] = new EndPoints(IMAGE_WIDTH, IMAGE_HEIGHT, i);
			endpoints[i].toString();
		}
		
		gc = canvas.getGraphicsContext2D();
		pw = gc.getPixelWriter();
		
		startTime = System.nanoTime();
		
		for(int i = 0; i < numLines; i++) {
			
			start = endpoints[i].getStartPoint();
			end = endpoints[i].getEndPoint();
			x0 = start[0];
			y0 = start[1];
			slope = endpoints[i].getSlope();
			x = x0;
			y = y0;
		
			/*
			 * These loops handle the drawing of the lines. The order of the
			 * if-else statements is designed to catch special cases (horizontal
			 * and vertical lines) before the slope is checked in order to avoid
			 * errors, like comparing an undefined slope.
			 */
			
			if(simple == true) { 
			//Vertical Lines
				if (endpoints[i].getDiffX() == 0) {
					for(int j = 0; j < endpoints[i].getDiffY() - 1; j++) {
						x = x0;
						y = y0 + j;
					
						if (dashLength == 0)
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j + 1) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)
								pw.setColor(x, y, Color.WHITE);
						}
					}
				}
				//Horizontal Lines
				else if (endpoints[i].getDiffY() == 0) {
					for(int j = 0; j < endpoints[i].getDiffX() - 1; j++) {
						x = x0 + j;
					
						if (dashLength == 0) 
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j + 1) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)	
								pw.setColor(x, y0, Color.WHITE);
						}
					}
				}
				//DiffX > DiffY
				else if (Math.abs(slope) < 1) {
					for(int j = 0; j < endpoints[i].getDiffX() - 1; j++) {
						x = x0 + j;
						y = (int)((slope * j) + y0);
					
						if (dashLength == 0)
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j + 1) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)	
								pw.setColor(x, y, Color.WHITE);
						}
					}
				}
				//DiffY > DiffX
				else if (Math.abs(slope) > 1) {
					for(int j = 0; j < endpoints[i].getDiffY() - 1; j++) {
						x = (int)(((1/slope)*j) + x0);
						y = y0 + j;
					
						if (dashLength == 0)
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j + 1) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)	
								pw.setColor(x, y, Color.WHITE);
						}
					}
				}
				//Perfect diagonal (DiffY = DiffX)
				else if (Math.abs(slope) == 1) {
					for(int j = 0; j < endpoints[i].getDiffX() - 1; j++) {
						x = x0 + j;
						y = y0 + j;
					
						if (dashLength == 0)
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j + 1) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)
								pw.setColor(x, y, Color.WHITE);
						}
					}
				}
			}
			else if(bresenham == true) {
				
				int j = 1;
				//horizontal 
				if(endpoints[i].getDiffY() == 0) {
				
					do {
						
						if (dashLength == 0)
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)
								pw.setColor(x, y, Color.WHITE);
						}
						
						x += 1;
						
						if(x >= end[0])
							break;
							
						j++;
					} while(true);
				}
				//vertical
				else if(endpoints[i].getDiffX() == 0) {
				
					do {
					
						if (dashLength == 0)
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)
								pw.setColor(x, y, Color.WHITE);
						}
						
						y += 1;
						
						if(y >= end[1])
							break;
							
						j++;
					} while(true);
				}
				//positive slope less than one
				else if(slope > 0 && Math.abs(slope) < 1) {
				
					err = 2*(endpoints[i].getDiffY() - endpoints[i].getDiffX());
					inc1 = 2*endpoints[i].getDiffY();
					inc2 = 2*(endpoints[i].getDiffY() - endpoints[i].getDiffX());
					
					do {
					
						if (dashLength == 0)
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)
								pw.setColor(x, y, Color.WHITE);
						}
					
						if(err < 0) 
							err += inc1;
						else {
							y = y+1;
							err += inc2;
						}
						
						x += 1;
					
						if(x >= end[0]) 
							break;
							
						j++;
					} while (true);
				}
				//negative slope less than one 
				else if(slope < 0 && Math.abs(slope) < 1){
					
					err = 2*(endpoints[i].getDiffY() - endpoints[i].getDiffX());
					inc1 = 2*endpoints[i].getDiffY();
					inc2 = 2*(endpoints[i].getDiffY() - endpoints[i].getDiffX());
					
					do {
					
						if (dashLength == 0)
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)
								pw.setColor(x, y, Color.WHITE);
						}
						
						if(err < 0)
							err += inc1;
						else {
							y = y-1;
							err += inc2;
						}
						
						x += 1;
						
						if(x >= end[0])
							break;
							
						j++;
					} while(true);
				}
				//positive slope greater than one
				else if(slope > 0 && Math.abs(slope) > 1) {
				
					err = 2*(endpoints[i].getDiffX() - endpoints[i].getDiffY());
					inc1 = 2*endpoints[i].getDiffX();
					inc2 = 2*(endpoints[i].getDiffX() - endpoints[i].getDiffY());
					
					do {
						
						if (dashLength == 0)
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)
								pw.setColor(x, y, Color.WHITE);
					}
						
						if(err < 0)
							err += inc1;
						else {
							x = x+1;
							err += inc2;
						}
						
						y += 1;
						
						if(y >= end[1])
							break;
							
						j++;
					} while(true);
				}
				//negative slope greater than one
				else if(slope < 0 && Math.abs(slope) > 1) {
				
					err = 2*(endpoints[i].getDiffX() - endpoints[i].getDiffY());
					inc1 = 2*endpoints[i].getDiffX();
					inc2 = 2*(endpoints[i].getDiffX() - endpoints[i].getDiffY());
				
					do {
					
						if (dashLength == 0)
							pw.setColor(x, y, Color.WHITE);
						else {
							if ((j) % dashLength == 0)
								drawDash = !drawDash;
							if (drawDash == true)
								pw.setColor(x, y, Color.WHITE);
						}
						
						if(err < 0)
							err += inc1;
						else {
							x = x-1;
							err += inc2;
						}
						
						y += 1;
						
						if(y >= end[1])
							break;
							
						j++;
					} while(true);
				}
			}		
		
		}
		
		endTime = System.nanoTime();
		duration = (endTime - startTime) / 1000000;
		
		System.out.println("");
		System.out.println("Execution time: " + duration + " ms");
		System.out.println("");
		
	}//handleDrawButtonAction
}//LineController 
