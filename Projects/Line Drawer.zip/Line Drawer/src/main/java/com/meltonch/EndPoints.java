package com.meltonch;

import java.util.Random;

public class EndPoints {

	/**
	 * An integer containing the set number of the coordinate pair. This 
	 * is to be used for identification purposes.
	 */
	private int setNum;
	
	/**
	 * Integers that store the ABSOLUTE values of the change in x and change in y.
	 */
	private int diffX;
	private int diffY;

	/**
	 * Two arrays that designate the x (index 0) and y (index 1) coordinates 
	 * of the start and endpoints of a line.
	 */
	private int[] start;
	private int[] end;
	
	/**
	 * Double value representing the slope of the line created by the start and 
	 * end points.
	 */
	private double slope;
	
	/**
	 * Generates random endpoints bounded within a given width and height. Calculates
	 * the slope once all points are generated.
	 *
	 * @param width The width of the space in which the endpoints will be generated.
	 * @param height The height of the space in which the endpoints will be generated.
	 * @param num the identifying number for the set of points 
	 */
	public EndPoints(int width, int height, int num) {
	
		setNum = num;
	
		start = new int[2];
		end = new int[2];

		Random rand = new Random();
	
		//starting x coordinate
		start[0] = rand.nextInt(width);
		
		//starting y coordinate
		start[1] = rand.nextInt(height);
		
		//ending x coordinate
		end[0] = rand.nextInt(width);
		
		//ending y coordinate
		end[1] = rand.nextInt(height);
		
		//calculate slope 
		slope = ((double)(end[1] - start[1])/(double)(end[0] - start[0]));
		
		//ensures points are in increasing order by x-value 
		//if slope is greater than zero or equal to one
		if (slope > 0 || slope == 1 || (slope < 0 && Math.abs(slope) < 1)) {
			if (start[0] > end[0]) {
				int[] tmp = start;
				start = end;
				end = tmp;
			}
		}
		//ensures points are in increasing order by y value
		//if slope is less than zero or equal to infinity
		else if (slope < 0 && Math.abs(slope) > 1) {
			if (start[1] > end[1]) {
				int[] tmp = start;
				start = end;
				end = tmp;
			}
		}
		
		//calculate x and y differences
		diffX = Math.abs(end[0] - start[0]);
		diffY = Math.abs(end[1] - start[1]); 
	}
	
	/**
	 * Returns the array containing the coordinates for the starting point.
	 *
	 * @return start the array containing coordinates for the starting point.
	 */
	public int[] getStartPoint() {
	
		return start;
		
	}
	
	/**
	 * Returns the array containing the coordinates for the end point.
	 *
	 * @return end the array containing the coordinates for the end point.
	 */
	public int[] getEndPoint() {
	
		return end;
		
	}
	
	/**
	 * Returns the slope of the line between the start and the end points.
	 *
	 * @return slope the slope of the line represented by the start and end points.
	 */
	public double getSlope() {
	
		return slope;
		
	}
	
	/**
	 * Returns the ABSOLUTE value of the difference in X.
	 *
	 * @return diffX the difference in X values.
	 */
	public int getDiffX() {
	
		return diffX;
		
	}
	
	/**
	 * Returns the ABSOLUTE value of the difference in Y.
	 *
	 * @return diffY the difference in Y values.
	 */
	public int getDiffY() {
	
		return diffY;
		
	}
	
	/**
	 * Override for the toString method. In this case, toString should display
	 * coordinate information in a neat, formatted fashion.
	 *
	 * @return N/A. Function prints to command line, then returns a blank string.
	 */
	@Override 
	public String toString() {
	
		System.out.println("");
		System.out.println(setNum + ". (" + start[0] + " , " + start[1] + ")"
							+ "(" + end[0] + " , " + end[1] + ") slope: " + slope);
		System.out.println("");
		
		return "";
	
	}
}