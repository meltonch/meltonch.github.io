package com.meltonch;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Line Drawer Application. This program runs a GUI that draws a number of lines
 * based on a user-supplied number. 
 * 
 * @author Chase Melton <meltonch@uga.edu>
 */
public class LineDrawer extends Application {
	
	/**
	 * The main method, where the program is launched.
	 */
	public static void main(String[] args) {
		Application.launch(LineDrawer.class, args);
	}// main
	
	/**
	 * Start method that handles setting up application details.
	 *
	 * @param stage the application stage 
	 * @throws ioe will throw an exception if the supplied fxml document can't be found or loaded.
	 */
	@Override
	public void start(Stage stage) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/LineDisplay.fxml"));
		stage.setTitle("FXML Template");
		
		Scene scene = new Scene(root, 1200, 900);
		
		stage.setScene(scene);
		stage.show();
	}// start 
	
}// FXMLDriver 