$(document).ready(function(){
	
	$('#pageText').fadeIn('medium');
	
	$('.1').click(function(){
		
		$('.upnext').slideToggle('medium');
		
	});
	
	$('.2').click(function(){
		
		$('.awaffle').slideToggle('medium');
		
	});
	
	$('.3').click(function(){
		
		$('.lines').slideToggle('medium');
		
	});
	
	$('.4').click(function(){
		
		$('.3D').slideToggle('medium');
		
	});
	
	$('.5').click(function(){
		
		$('.misc').slideToggle('medium');
		
	});

});