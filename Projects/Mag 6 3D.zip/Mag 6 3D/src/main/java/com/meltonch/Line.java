package com.meltonch;

import java.util.ArrayList;

/**
 * This class represents a line object, which consists of two EndPoints 
 * objects and an int that indicates the index of the ArrayList<EndPoints>
 * where the starting EndPoints object is located.
 *
 * @author Chase Melton <meltonch@uga.edu>
 */
public class Line {

	/**
	 * EndPoints objects representing the start point and end point 
	 * of the line.
	 */
	private EndPoints2D start, end;
	
	/**
	 * Ints representing the location in the ArrayList<EndPoints> where 
	 * the starting and ending coordinates are located.
	 */
	private int sindex, eindex;
	
	/**
	 * This constructor initializes the two EndPoints objects and the int.
	 *
	 * @param s the starting EndPoints object.
	 * @param e the ending EndPoints object.
	 * @param si The index of the starting point 
	 * @param ei the index of the ending point
	 */
	public Line(EndPoints2D s, EndPoints2D e, int si, int ei) {
	
		start = s;
		end = e;
		
		sindex = si;
		eindex = ei;
		
	}//Line 
	
	/**
	 * For situations where the index of the vertices doesn't matter.
	 *
	 * @param s the starting EndPoints object.
	 * @param e the ending EndPoints ibject.
	 */
	public Line(EndPoints2D s, EndPoints2D e) {
	
		start = s;
		end = e;
		
	}
	
	/**
	 * Returns the starting point of the line.
	 * 
	 * @return start EndPoints object representing the starting point.
	 */
	public EndPoints2D getStart() {
	
		return start;
		
	}//getStart 
	
	/**
	 * Returns the ending point of the line. 
	 *
	 * @return end EndPoints object representing the ending point.
	 */
	public EndPoints2D getEnd() {
	
		return end;
		
	}//getEnd
	
	/**
	 * Utility method to set the starting point of the line. Only meant to 
	 * be used when <code>xindex</code> will be preserved.
	 *
	 * @param s the new starting point of the line.
	 */
	public void setStart(EndPoints2D s) {
	
		start = s;
		
	}//setStart 
	
	/**
	 * utility method to set the ending point of the line. Only meant to 
	 * be used when <code>xindex</code> will be preserved.
	 *
	 * @param e the new ending point of the line.
	 */
	 public void setEnd(EndPoints2D e) {
	
		end = e;
		
	}//setEnd
	
	/**
	 * Utility method to update the starting and ending points of 
	 * the line. This method should be called whenever the ArrayList<EndPoints>
	 * containing line vertices is changed.
	 *
	 * @param vertices The ArrayList<EndPoints> containing line vertices.
	 */
	public static ArrayList<Line> update(ArrayList<EndPoints2D> vertices, ArrayList<Line> lines) {

		int vsindex, veindex;
		
		for(int i = 0; i < lines.size(); i++) {
		
			vsindex = lines.get(i).getStartIndex();
			veindex = lines.get(i).getEndIndex();
			
			lines.set(i, new Line(vertices.get(vsindex), vertices.get(veindex), vsindex, veindex));
			
		}
		
		return lines;
		
	}//update

	/**
	 * Returns the index in vertices of the starting point of the line.
	 *
	 * @return sindex the index of the starting point in vertices
	 */
	public int getStartIndex() {
	
		return sindex;
		
	}//getStartIndex
	
	/**
	 * Returns the index in vertices of the ending point of the line.
	 *
	 * @return eindex the index of the ending point in vertices
	 */
	public int getEndIndex() {
	
		return eindex;
		
	}//getEndIndex
	
	public ArrayList<EndPoints2D> updateVertices(ArrayList<Line> lines) {
	
		ArrayList<EndPoints2D> tmp = new ArrayList<EndPoints2D>();
		
		for(int i = 0; i < lines.size(); i++) {
		
			tmp.add(lines.get(i).getStart());
			tmp.add(lines.get(i).getEnd());
			
		}

		return tmp;
		
	}
	
	
	/**
	 * toString Override for debugging purposes. Prints the details by 
	 * calling the toString methods of the individual EndPoints objects.
	 * 
	 * @return s undefined string variable, returns a useless message.
	 */
	@Override
	public String toString() {
	
		System.out.println("Line:");
		System.out.print("	");
		start.toString();
		System.out.println("");
		System.out.print("	");
		end.toString();
		System.out.println("");
		
		return "USELESS MESSAGE!!!";
		
	}//toString
	
}