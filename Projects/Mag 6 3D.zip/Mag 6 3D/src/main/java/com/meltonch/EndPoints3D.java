package com.meltonch;

import java.util.Random;

/**
 * As of the start of development of Sapphire Basic version Alpha, This class
 * has been modified to contain only one point instead of two. All calculation
 * and ordering utilities have been moved to the LineDrawer class, which handles
 * drawing the lines. 
 */
public class EndPoints3D {
	
	/**
	 * One array that designates the x (index 0) and y (index 1) coordinates 
	 * of a point. 
	 */
	private double[] point;
	
	/**
	 * Generates random endpoints bounded within a given width and height. Calculates
	 * the slope once all points are generated.
	 *
	 * @param width The width of the space in which the endpoints will be generated.
	 * @param height The height of the space in which the endpoints will be generated.
	 * @param num the identifying number for the set of points 
	 */
	public EndPoints3D(double x, double y, double z) {
	
		point = new double[3];
		point[0] = x;
		point[1] = y;
		point[2] = z;
		
	}
	
	public double getX() {
	
		return point[0];
		
	}//getX

	public double getY() {
	
		return point[1];
		
	}//getY()
	
	public double getZ() {
	
		return point[2];
		
	}//getZ
	
	public void setX(double x) {
	
		point[0] = x;
	
	}
	
	public void setY(double y) {
	
		point[1] = y;
	
	}
	
	public void setZ(double z) {
	
		point[2] = z;
		
	}//setZ
	
	@Override
	public String toString() {
	
		System.out.println("");
		System.out.println("(" + point[0] + ", " + point[1] + ", " + point[2] + ")");
		System.out.println("");
		
		return "NO ONE SHALL SEE THIS MESSAGE!!!";
		
	}//toString 
	
}