package com.meltonch;

import java.util.Random;

/**
 * Mag 6 3D uses the endpoints 2D class to store the transformed points,
 * NOT the raw 3D (x,y,z) points. EndPoints3D objects are transformed via
 * perspective projection and the resulting screen coordinates (x,y) are stored
 * in EndPoints2D objects.
 */
public class EndPoints2D {
	
	/**
	 * One array that designates the x (index 0) and y (index 1) coordinates 
	 * of a point. 
	 */
	private int[] point;
	
	/**
	 * Generates random endpoints bounded within a given width and height. Calculates
	 * the slope once all points are generated.
	 *
	 * @param width The width of the space in which the endpoints will be generated.
	 * @param height The height of the space in which the endpoints will be generated.
	 * @param num the identifying number for the set of points 
	 */
	public EndPoints2D(int x, int y) {
	
		point = new int[2];
		point[0] = x;
		point[1] = y;
	
	}
	
	public int getX() {
	
		return point[0];
		
	}//getX

	public int getY() {
	
		return point[1];
		
	}//getY()
	
	public void setX(int x) {
	
		point[0] = x;
	
	}
	
	public void setY(int y) {
	
		point[1] = y;
	
	}
	
	@Override
	public String toString() {
	
		System.out.println("");
		System.out.println("(" + point[0] + ", " + point[1] + ")");
		System.out.println("");
		
		return "NO ONE SHALL SEE THIS MESSAGE!!!";
		
	}//toString 
	
}