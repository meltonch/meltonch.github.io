package com.meltonch;

import java.util.ArrayList;
import javafx.scene.canvas.Canvas;

/**
 * MatrixTransform builds and applies matrix representations
 * of 2D transformations. This class also manages transformation arrays
 * and their applications.
 *
 * @author Chase Melton <meltonch@uga.edu>
 */
public class MatrixTransform3D {

	/**
	 * 2D 3x3 array representing a translation.
	 */
	private double[][] translate = new double[4][4];
	
	/**
	 * 2D 3x3 array representing a scale.
	 */
	private double[][] scale = new double[4][4];
	
	/**
	 * 2D 3x3 array representing a rotation.
	 */
	private double[][] rotate = new double[4][4];
	
	/**
	 * 2D 3x3 array representing an overall transformation.
	 */
	private double[][] transform = new double[4][4];
	
	private double[][] n = new double[4][4];
	
	/**
	 * ArrayList used to hold all transformation matricies for use 
	 * in the concatenation method.
	 */
	public static ArrayList<double[][]> transformList = new ArrayList<double[][]>();
	
	private double d, s;
	
	private int vsx, vsy, vcx, vcy;
	
	private EndPoints3D eye; 

	
	/**
	 * Constructs a MatrixTransform object. Initially, all arrays are set to 
	 * the 3x3 identity matrix.
	 */
	public MatrixTransform3D() {
	
		translate = new double[][]{
			{1, 0, 0, 0},
			{0, 1, 0, 0},
			{0, 0, 1, 0},
			{0, 0, 0, 1}
		};
		
		scale = new double[][]{
			{1, 0, 0, 0},
			{0, 1, 0, 0},
			{0, 0, 1, 0},
			{0, 0, 0, 1}
		};
		
		rotate = new double[][]{
			{1, 0, 0, 0},
			{0, 1, 0, 0},
			{0, 0, 1, 0},
			{0, 0, 0, 1}
		};
		
		transform = new double[][]{
			{1, 0, 0, 0},
			{0, 1, 0, 0},
			{0, 0, 1, 0},
			{0, 0, 0, 1}
		};
		
		n = new double[][]{
			{1, 0, 0, 0},
			{0, 1, 0, 0},
			{0, 0, 1, 0},
			{0, 0, 0, 1} 
		};
			
	}//MatrixTransform 
	
	/**
	 * Applies the transformation. Takes in vertices and creates matrix representation
	 * of the EndPoints coordinates, then multiplies it by transform. Resets 
	 * transform at the end of application.
	 */
	public ArrayList<EndPoints3D> applyTransformation(ArrayList<EndPoints3D> vertices) {
	
		resetAll();
	
		double[] tmp = new double[4];
	
		concatenate();
		
		for(int i = 0; i < vertices.size(); i++) {
			tmp[0] = vertices.get(i).getX();
			tmp[1] = vertices.get(i).getY();
			tmp[2] = vertices.get(i).getZ();
			tmp[3] = 1;
			
			vertices.get(i).setX(
				(int)(
					(tmp[0]*transform[0][0]) +
					(tmp[1]*transform[1][0]) +
					(tmp[2]*transform[2][0]) +
					(tmp[3]*transform[3][0])
				)
			);
			
			vertices.get(i).setY(
				(int)(
					(tmp[0]*transform[0][1]) +
					(tmp[1]*transform[1][1]) +
					(tmp[2]*transform[2][1]) +
					(tmp[3]*transform[3][1])
				)
			);
			
			vertices.get(i).setZ(
				(int)(
					(tmp[0]*transform[0][2]) +
					(tmp[1]*transform[1][2]) +
					(tmp[2]*transform[2][2]) +
					(tmp[3]*transform[3][2])
				)
			);
			
			System.out.println(i + ": " + vertices.get(i).getX() + " " + vertices.get(i).getY() + " " + vertices.get(i).getZ());
			
		}//for 
		
	
		return vertices;
		
	}//applyTransformation
	
	/**
	 * Multiplies all matricies in transformList and stores them in transform.
	 * transformList is cleared at the end of the process.
	 */
	public void concatenate() {
	
		resetTransform();
	
		double[][] tmp;
		double[][] tmp2 = new double[4][4];
	
		for(int i = 0; i < transformList.size(); i++) {
		
			tmp = transformList.get(i);
			for(int j = 0; j < transform.length; j++) {
				for(int k = 0; k < transform[j].length; k++) {
					tmp2[j][k] = transform[j][k];
				}
			}
		
			transform[0][0] = (
				(tmp2[0][0]*tmp[0][0]) +
				(tmp2[0][1]*tmp[1][0]) +
				(tmp2[0][2]*tmp[2][0]) + 
				(tmp2[0][3]*tmp[3][0])
			);
			
			transform[0][1] = (
				(tmp2[0][0]*tmp[0][1]) +
				(tmp2[0][1]*tmp[1][1]) +
				(tmp2[0][2]*tmp[2][1]) +
				(tmp2[0][3]*tmp[3][1])
			);
			
			transform[0][2] = (
				(tmp2[0][0]*tmp[0][2]) +
				(tmp2[0][1]*tmp[1][2]) +
				(tmp2[0][2]*tmp[2][2]) +
				(tmp2[0][3]*tmp[3][2])
			);
			
			transform[0][3] = (
				(tmp2[0][0]*tmp[0][3]) +
				(tmp2[0][1]*tmp[1][3]) +
				(tmp2[0][2]*tmp[2][3]) +
				(tmp2[0][3]*tmp[3][3])
			);
			
			transform[1][0] = (
				(tmp2[1][0]*tmp[0][0]) +
				(tmp2[1][1]*tmp[1][0]) +
				(tmp2[1][2]*tmp[2][0]) +
				(tmp2[1][3]*tmp[3][0])
			);
			
			transform[1][1] = (
				(tmp2[1][0]*tmp[0][1]) +
				(tmp2[1][1]*tmp[1][1]) +
				(tmp2[1][2]*tmp[2][1]) +
				(tmp2[1][3]*tmp[3][1])
			);
			
			transform[1][2] = (
				(tmp2[1][0]*tmp[0][2]) +
				(tmp2[1][1]*tmp[1][2]) +
				(tmp2[1][2]*tmp[2][2]) +
				(tmp2[1][3]*tmp[3][2])
			);
			
			transform[1][3] = (
				(tmp2[1][0]*tmp[0][3]) +
				(tmp2[1][1]*tmp[1][3]) +
				(tmp2[1][2]*tmp[2][3]) +
				(tmp2[1][3]*tmp[3][3])
			);
			
			transform[2][0] = (
				(tmp2[2][0]*tmp[0][0]) +
				(tmp2[2][1]*tmp[1][0]) +
				(tmp2[2][2]*tmp[2][0]) +
				(tmp2[2][3]*tmp[3][0])
			);
			
			transform[2][1] = (
				(tmp2[2][0]*tmp[0][1]) +
				(tmp2[2][1]*tmp[1][1]) +
				(tmp2[2][2]*tmp[2][1]) +
				(tmp2[2][3]*tmp[3][1])
			);
			
			transform[2][2] = (
				(tmp2[2][0]*tmp[0][2]) +
				(tmp2[2][1]*tmp[1][2]) +
				(tmp2[2][2]*tmp[2][2]) +
				(tmp2[2][3]*tmp[3][2])
			);
			
			transform[2][3] = (
				(tmp2[2][0]*tmp[0][3]) +
				(tmp2[2][1]*tmp[1][3]) +
				(tmp2[2][2]*tmp[2][3]) +
				(tmp2[2][3]*tmp[3][3])
			);
			
			transform[3][0] = (
				(tmp2[3][0]*tmp[0][0]) +
				(tmp2[3][1]*tmp[1][0]) +
				(tmp2[3][2]*tmp[2][0]) +
				(tmp2[3][3]*tmp[3][0])
			);
			
			transform[3][1] = (
				(tmp2[3][0]*tmp[0][1]) +
				(tmp2[3][1]*tmp[1][1]) +
				(tmp2[3][2]*tmp[2][1]) +
				(tmp2[3][3]*tmp[3][1])
			);
			
			transform[3][2] = (
				(tmp2[3][0]*tmp[0][2]) +
				(tmp2[3][1]*tmp[1][2]) +
				(tmp2[3][2]*tmp[2][2]) +
				(tmp2[3][3]*tmp[3][2])
			);
			
			transform[3][3] = (
				(tmp2[3][0]*tmp[0][3]) +
				(tmp2[3][1]*tmp[1][3]) +
				(tmp2[3][2]*tmp[2][3]) +
				(tmp2[3][3]*tmp[3][3])
			);
			
		}//for
		
		transformList.clear();
		
		//resetN();
		
	}//concatenate
	
	/**
	 * Sets and returns the matrix representation of a translation. 
	 * DOES NOT APPLY TRANSFORMATION.
	 *
	 * @param tx the x value of the translation.
	 * @param ty the y value of the translation.
	 * @param tz the z value of the transformation. 
	 * @return translate the matrix representation of a translation.
	 * @see applyTransformation for applying transformations. 
	 */	
	public double[][] translate(double tx, double ty, double tz) {
	
		translate[3][0] = tx;
		translate[3][1] = ty;
		translate[3][2] = tz;
		
		transformList.add(translate);
		
		return translate;
	
	}//translate
	
	/**
	 * Sets and returns the matrix representation of a scale. 
	 * DOES NOT APPLY TRANSFORMATION.
	 *
	 * @param sx the x value of the scale.
	 * @param sy the y value of the scale.
	 * @param sz the z value of the scale.
	 * @return scale the matrix representation of a scale.
	 * @see applyTransformation for applying transformations. 
	 */		
	public double[][] scale(double sx, double sy, double sz) {
	
		scale[0][0] = sx;
		scale[1][1] = sy;
		scale[2][2] = sz;
		
		transformList.add(scale);
		
		return scale;
		
	}//scale
	
	/**
	 * Sets and returns the matrix representation of a rotation. 
	 * DOES NOT APPLY TRANSFORMATION.
	 *
	 * @param deg The angle of rotation in degrees.
	 * @param axis the axis of rotation.
	 * @return rotate the matrix representation of a rotation.
	 * @see applyTransformation for applying transformations. 
	 */	
	public double[][] rotate(double deg, char axis) {
		
		if(axis == 'z') {
		
			rotate[0][0] = Math.cos(Math.toRadians(deg));
			rotate[0][1] = Math.sin(Math.toRadians(deg));
			rotate[1][0] = Math.sin(Math.toRadians(-deg));
			rotate[1][1] = Math.cos(Math.toRadians(deg));
			
		}
		else if(axis == 'y') {
		
			rotate[0][0] = Math.cos(Math.toRadians(deg));
			rotate[0][2] = Math.sin(Math.toRadians(-deg));
			rotate[2][0] = Math.sin(Math.toRadians(deg));
			rotate[2][2] = Math.cos(Math.toRadians(deg));
		
		}
		else if(axis == 'x') {
			
			rotate[1][1] = Math.cos(Math.toRadians(deg));
			rotate[1][2] = Math.sin(Math.toRadians(deg));
			rotate[2][1] = Math.sin(Math.toRadians(-deg));
			rotate[2][2] = Math.cos(Math.toRadians(deg));
			
		}
		
		transformList.add(rotate);
		
		return rotate;
	
	}
	
	/**
	 * Resets all transformation matricies and the overall transform 
	 * matrix to the 3x3 identity matrix.
	 */
	public void resetAll() {
	
		translate = new double[][]{
			{1, 0, 0, 0},
			{0, 1, 0, 0},
			{0, 0, 1, 0},
			{0, 0, 0, 1}
		};
		
		scale = new double[][]{
			{1, 0, 0, 0},
			{0, 1, 0, 0},
			{0, 0, 1, 0},
			{0, 0, 0, 1}
		};
		
		rotate = new double[][]{
			{1, 0, 0, 0},
			{0, 1, 0, 0},
			{0, 0, 1, 0},
			{0, 0, 0, 1}
		};
		
		transform = new double[][]{
			{1, 0, 0, 0},
			{0, 1, 0, 0},
			{0, 0, 1, 0},
			{0, 0, 0, 1}
		};
		
	}//resetAll 
	
	/**
	 * Resets ONLY the overall transformation matrix to the 3x3 identity matrix.
	 */
	public void resetTransform() {
	
		transform = new double[][]{
			{1, 0, 0, 0},
			{0, 1, 0, 0},
			{0, 0, 1, 0},
			{0, 0, 0, 1}
		};
		
	}//resetTransform
	
	public void clearTransformList() {
	
		transformList.clear();
		
	}
	
	public EndPoints2D convert2D(EndPoints3D ep) {
	
		double a, b;
	
		clearTransformList();
		
		/* T1 */
		transformList.add(
			new double[][]{
				{1, 0, 0, 0},
				{0, 1, 0, 0},
				{0, 0, 1, 0},
				{-(eye.getX()), -(eye.getY()), -(eye.getZ()), 1}
			}
		);
		
		/* T2 */
		transformList.add(
			new double[][]{
				{1, 0, 0, 0},
				{0, 0, -1, 0},
				{0, 1, 0, 0},
				{0, 0, 0, 1}
			}
		);
		
		a = ((double)eye.getY()/(double)Math.sqrt(Math.pow(eye.getY(), 2) + Math.pow(eye.getX(), 2)));
		b = ((double)eye.getX()/(double)Math.sqrt(Math.pow(eye.getY(), 2) + Math.pow(eye.getX(), 2)));
		
		/* T3 */
		transformList.add(
			new double[][]{
				{-a, 0, b, 0},
				{0, 1, 0, 0},
				{-b, 0, -a, 0},
				{0, 0, 0, 1} 
			}
		);
		
		a = (Math.sqrt(Math.pow(eye.getX(), 2) + Math.pow(eye.getY(), 2))
			/ Math.sqrt(Math.pow(eye.getZ(), 2) + Math.pow(eye.getX(), 2) + Math.pow(eye.getY(), 2)));
		b = ((double)eye.getZ() / Math.sqrt(Math.pow(eye.getZ(), 2) + Math.pow(eye.getX(), 2) + Math.pow(eye.getY(), 2)));	
		
		/* T4 here */
		transformList.add(
			new double[][]{
				{1, 0, 0, 0},
				{0, a, b, 0},
				{0, -b, a, 0},
				{0, 0, 0, 1}
			}
		);
		
		/* T5 here */
		transformList.add(
			new double[][]{
				{1, 0, 0, 0},
				{0, 1, 0, 0},
				{0, 0, -1, 0},
				{0, 0, 0, 1} 
			}
		);
	
		/* N here */ 
		n[0][0] = ((double)d/(double)s);
		n[1][1] = ((double)d/(double)s);

		transformList.add(n);
		
		/* concatenate all transformations */
		concatenate();
		
		/* convert resulting clipping coordinates to screen coordinates */
		double[] tmp = new double[] {ep.getX(), ep.getY(), ep.getZ(), 1};
		
		EndPoints3D clippingEP = new EndPoints3D(ep.getX(), ep.getY(), ep.getZ());
		
		clippingEP.setX(
			tmp[0]*transform[0][0] + 
			tmp[1]*transform[1][0] + 
			tmp[2]*transform[2][0] + 
			tmp[3]*transform[3][0]
		);

		clippingEP.setY(
			tmp[0]*transform[0][1] + 
			tmp[1]*transform[1][1] + 
			tmp[2]*transform[2][1] + 
			tmp[3]*transform[3][1]
		);
		
		clippingEP.setZ(
			tmp[0]*transform[0][2] + 
			tmp[1]*transform[1][2] + 
			tmp[2]*transform[2][2] + 
			tmp[3]*transform[3][2]
		);
		
		System.out.println(clippingEP.getX() + " " + clippingEP.getY() + " " + clippingEP.getZ());
		System.out.println(ep.getX() + " " + clippingEP.getY() + " " + clippingEP.getZ());
		
		resetTransform();
		
		/* create & return EndPoints2D object w/ screen coordinates */
		return new EndPoints2D(
			(int)(vsx*(clippingEP.getX()/clippingEP.getZ()) + vcx),
			(int)(vsy*(clippingEP.getY()/clippingEP.getZ()) + vcy)
		);
	
	}//convert2D
	
	public void setEye(double x, double y, double z) {
	
		eye = new EndPoints3D(x, y, z);
		
	}//setEye 
	
	public void resetN() {
	
		n[0][0] = 1;
		n[1][1] = 1;
		
	}//reset N 
	
	public void setNValues(int distance, int screen_size) {
	
		d = distance;
		s = screen_size/2;
		
	}//setNValues 
	
	public void setVPValues(int screen_x, int screen_y) {
	
		vsx = screen_x/2;
		vsy = screen_y/2;
		vcx = vsx;
		vcy = vsy;
		
	}//set VP Values
	
}//MatrixTransform 