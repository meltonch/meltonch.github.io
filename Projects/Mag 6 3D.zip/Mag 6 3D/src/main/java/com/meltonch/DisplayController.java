package com.meltonch;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.canvas.Canvas;
import javafx.event.ActionEvent;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Window;
import javafx.stage.Popup;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class DisplayController {

	protected static final int IMAGE_WIDTH = 1180, IMAGE_HEIGHT = 845;
	protected static final int WORLD_WIDTH = 10000, WORLD_HEIGHT = 10000;
	
	@FXML TextField dashField;
	@FXML TextField lineX1Field;
	@FXML TextField lineY1Field;
	@FXML TextField lineZ1Field;
	@FXML TextField lineX2Field;
	@FXML TextField lineY2Field;
	@FXML TextField lineZ2Field;
	@FXML TextField transXField;
	@FXML TextField transYField;
	@FXML TextField transZField;
	@FXML TextField scaleXField;
	@FXML TextField scaleYField;
	@FXML TextField scaleZField;
	@FXML TextField rotateField;
	@FXML TextField axisField;
	@FXML TextField vx0Field;
	@FXML TextField vy0Field;
	@FXML TextField vx1Field;
	@FXML TextField vy1Field;
	@FXML TextField distanceField;
	@FXML TextField sizeField;
	@FXML TextField eyeXField;
	@FXML TextField eyeYField;
	@FXML TextField eyeZField;
	@FXML Canvas canvas;
	int vx0 = 0, vy0 = 0, vx1 = IMAGE_WIDTH, vy1 = IMAGE_HEIGHT;
	int dashLength = 0;
	ArrayList<EndPoints3D> raw_points = new ArrayList<EndPoints3D>();
	ArrayList<EndPoints2D> vertices = new ArrayList<EndPoints2D>();
	LineDrawer ld = new LineDrawer();
	ArrayList<Line> lines = new ArrayList<Line>();
	ArrayList<Line> clippedLines = new ArrayList<Line>();
	MatrixTransform3D mt = new MatrixTransform3D();
	
	@FXML public void handleDashFieldAction(ActionEvent event) {
		dashLength = Integer.parseInt(dashField.getText());
		System.out.println("Dash Length: " + dashLength);
	}
	
	/**
	 * Adds the values from the line points fields to the vertices ArrayList 
	 * as EndPoints objects. Draws the line.
	 */
	@FXML public void handleDrawLineButtonAction(ActionEvent event) {
	
		raw_points.add(
			new EndPoints3D(
				Integer.parseInt(lineX1Field.getText()), 
				Integer.parseInt(lineY1Field.getText()),
				Integer.parseInt(lineZ1Field.getText())
			)
		);
		
		raw_points.add(
			new EndPoints3D(
				Integer.parseInt(lineX2Field.getText()), 
				Integer.parseInt(lineY2Field.getText()),
				Integer.parseInt(lineZ2Field.getText())
			)
		);
		
		for(int i = 0; i < raw_points.size(); i++) {
		
			vertices.add(mt.convert2D(raw_points.get(i)));
			
		}
		
		lines.add(
			new Line(
				vertices.get(vertices.size()-2), 
				vertices.get(vertices.size()-1),
				(vertices.size()-2), 
				(vertices.size()-1)
			)
		);
		
		lines.get(lines.size()-1).toString();
		
		ld.draw(lines.get(lines.size()-1), canvas, dashLength);
		
	}//handleDrawLineButtonAction
	
	@FXML public void handleClearButtonAction(ActionEvent event) {
	
		ld.clear(canvas);
		raw_points.clear();
		vertices.clear();
		lines.clear();
		mt.resetAll();
		
	}//handleClearButtonAction
	
	@FXML public void handleTranslateButtonAction(ActionEvent event) {
	
		mt.translate(
			Double.parseDouble(transXField.getText()), 
			Double.parseDouble(transYField.getText()), 
			Double.parseDouble(transZField.getText())
		);
		
		raw_points = mt.applyTransformation(raw_points);
		
		for(int i = 0; i < raw_points.size(); i++) {
		
			raw_points.get(i).toString();
			vertices.set(i, mt.convert2D(raw_points.get(i)));
			
		}
		
		lines = Line.update(vertices, lines);
		
		ld.clear(canvas);
		
		/*for(int i = 0; i < lines.size(); i++) {
		
			lines.get(i).updateLine(vertices);
			
			lines.get(i).toString();
			
		}*/
		
		for(int i = 0; i < lines.size(); i++) {
		
			ld.draw(lines.get(i), canvas, dashLength);
			
		}
	
	}//handleTranslateButtonAction
	
	@FXML public void handleScaleButtonAction(ActionEvent event) {
	
		mt.scale(
			Double.parseDouble(scaleXField.getText()), 
			Double.parseDouble(scaleYField.getText()), 
			Double.parseDouble(scaleZField.getText())
		);
		
		raw_points = mt.applyTransformation(raw_points);
		
		for(int i = 0; i < raw_points.size(); i++) {
		
			vertices.set(i, mt.convert2D(raw_points.get(i)));
			
		}
		
		lines = Line.update(vertices, lines);
		
		ld.clear(canvas);
		
		for(int i = 0; i < lines.size(); i++) {
		
			ld.draw(lines.get(i), canvas, dashLength);
			
		}
		
	}//handleScaleButtonAction 
	
	@FXML public void handleRotateButtonAction(ActionEvent event) {
	
		mt.rotate(Double.parseDouble(rotateField.getText()), axisField.getText().charAt(0));
		raw_points = mt.applyTransformation(raw_points);
		
		for(int i = 0; i < raw_points.size(); i++) {
		
			vertices.set(i, mt.convert2D(raw_points.get(i)));
			
		}
		
		lines = Line.update(vertices, lines);
		
		ld.clear(canvas);
		
		for(int i = 0; i < lines.size(); i++) {
		
			ld.draw(lines.get(i), canvas, dashLength);
			
		}
		
	}//handleRotateButtonAction 
	
	@FXML public void handleReadGoButtonAction(ActionEvent event) {
	
		ld.clear(canvas);
		raw_points.clear();
		vertices.clear();
		lines.clear();
	
		int index1, index2;
	
		System.out.println("Reading File...");
	
		Window window = new Popup();
	
		FileChooser fc = new FileChooser();
		fc.setTitle("Read Lines File");
		fc.getExtensionFilters().addAll(
			new ExtensionFilter("Sapphire Basic Lines Files", "*.sbl"),
			new ExtensionFilter("All Files", "*.*")
		);
		
		fc.setInitialDirectory(new File(
			"C:\\Users\\Chase Melton\\Documents\\UGA\\Fall 2014\\CSCI 4810\\Mag 6 3D\\src\\main\\resources\\sbl"
			)
		);
		
		File file = fc.showOpenDialog(window);
		
			try {
				Scanner in = new Scanner(file);
				
				while(!(in.hasNext("->"))) {
					raw_points.add(
						new EndPoints3D(
							in.nextInt(),
							in.nextInt(),
							in.nextInt()
						)
					);
				} 
				
				/* skip the delimiter */
				in.next();
				
				for(int i = 0; i < raw_points.size(); i++) {
		
					vertices.add(i, mt.convert2D(raw_points.get(i)));
			
				}
			
				while(in.hasNext()) {
				
					index1 = in.nextInt();
					index2 = in.nextInt();
				
					lines.add(
						new Line(
							vertices.get(index1), 
							vertices.get(index2),
							(index1),
							(index2)
						)
					);
				}//while 
		
				for(int i = 0; i < lines.size(); i++) {
		
					ld.draw(lines.get(i), canvas, dashLength);
			
				}
				
			} catch(FileNotFoundException fnfe) {
				System.out.println("Error: File not found." + fnfe);
			}
			
	}//handleReadGoButtonAction
	
	@FXML public void handleWriteButtonAction(ActionEvent event) {}
	
	@FXML public void handleSetViewportButtonAction(ActionEvent event) {
	
		ld.clear(canvas);
		clippedLines.clear();
	
		vx0 = Integer.parseInt(vx0Field.getText());
		vy0 = Integer.parseInt(vy0Field.getText());
		vx1 = Integer.parseInt(vx1Field.getText());
		vy1 = Integer.parseInt(vy1Field.getText());
		
		clippedLines = ld.clip(lines, vx0, vy0, vx1, vy1, 0, 0, IMAGE_WIDTH, IMAGE_HEIGHT);
		
		for(int i = 0; i < clippedLines.size(); i++) {
		
			ld.draw(clippedLines.get(i), canvas, dashLength);
			
			clippedLines.get(i).toString();
			
		}
		
	}
	
	@FXML public void handleClearTransformListButton(ActionEvent event) {
	
		mt.clearTransformList();
		
	}
	
	@FXML public void handleApplyTransformButton(ActionEvent event) {
	
		mt.applyTransformation(raw_points);
		
		for(int i = 0; i < raw_points.size(); i++) {
		
			vertices.set(i, mt.convert2D(raw_points.get(i)));
			
		}
	
		ld.clear(canvas);
	
		for(int i = 0; i < lines.size(); i++) {
		
			lines = Line.update(vertices, lines);
			
			lines.get(i).toString();
			
		}
		
		for(int i = 0; i < lines.size(); i++) {
		
			ld.draw(lines.get(i), canvas, dashLength);

		}
	
	}//applytransform
	
	@FXML public void handleScreenStatsButtonAction(ActionEvent event) {
	
		mt.setNValues(Integer.parseInt(distanceField.getText()), Integer.parseInt(sizeField.getText()));
		mt.setVPValues(IMAGE_WIDTH, IMAGE_HEIGHT);
	
	}
	
	@FXML public void handleSetEyeButtonAction(ActionEvent event) {
	
		mt.setEye(
			Double.parseDouble(eyeXField.getText()),
			Double.parseDouble(eyeYField.getText()),
			Double.parseDouble(eyeZField.getText())
		);
	
	}
	
}//LineController 