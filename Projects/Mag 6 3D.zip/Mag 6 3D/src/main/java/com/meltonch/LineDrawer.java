package com.meltonch;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.PixelWriter;
import javafx.scene.paint.Color;
import java.util.ArrayList;

/**
 * This class represents the LineDrawer Object, an Object that draws
 * lines. It handles all necessary utilities involved in the action.
 */
public class LineDrawer {

	GraphicsContext gc;
	PixelWriter pw;

	/**
	 * The constructor handles setting up the pixel writer so that one instance
	 * of this object always refers to the same drawing space.
	 * 
	 * @param canvas The drawing space 
	 */
	public LineDrawer() {}
	
	/**
	 * draw is the function that handles drawing lines. It takes in two EndPoints objects
	 * and draws a line between them using the PixelWriter set up in the constructor.
	 * Bresenham's algorithm calculates all pixel positions.
	 *
	 * @param start The starting point of the line to be drawn.
	 * @param end The ending point of the line to be drawn.
	 * @param dashLength The length of segment dashes in the line
	 */
	public void draw(Line line, Canvas canvas, int dashLength) {
	
		EndPoints2D start = line.getStart();
		EndPoints2D end = line.getEnd();
	
		gc = canvas.getGraphicsContext2D();
		pw = gc.getPixelWriter();
	
		int diffX, diffY;
		int x, y, x0, y0 = 0;
		int err, inc1, inc2;
		double slope;
		boolean drawDash = true;
		
		//calculate slope 
		slope = ((double)(end.getY() - start.getY())/(double)(end.getX() - start.getX()));
		
		//ensures points are in increasing order by x-value 
		//if slope is greater than zero or equal to one
		if (slope > 0 || slope == 1 || (slope < 0 && Math.abs(slope) < 1) || slope == 0) {
			if (start.getX() > end.getX()) {
				EndPoints2D tmp = start;
				start = end;
				end = tmp;
			}
		}
		//ensures points are in increasing order by y value
		//if slope is less than zero or equal to infinity
		else if (slope < 0 && Math.abs(slope) > 1) {
			if (start.getY() > end.getY()) {
				EndPoints2D tmp = start;
				start = end;
				end = tmp;
			}
		}
		
		//calculate x and y differences
		diffX = Math.abs(end.getX() - start.getX());
		diffY = Math.abs(end.getY() - start.getY());	
		
		//set starting values 
		x0 = start.getX();
		y0 = start.getY();
		x = x0;
		y = y0;
			
		//loop counter	
		int i = 1;
		
		//DRAW SUM LINES!!!
		//perfectly diagonal
		if(Math.abs(slope) == 1) {
		
			do {
				
				if (dashLength == 0)
					pw.setColor(x, y, Color.WHITE);
				else {
					if ((i) % dashLength == 0)
						drawDash = !drawDash;
					if (drawDash == true)
						pw.setColor(x, y, Color.WHITE);
				}
				
				x += 1;
				y += 1;
				
				if(x >= end.getX())
					break;
					
				i++;
			} while(true);
		}
		//horizontal 
		if(diffY == 0) {
		
			do {
				
				if (dashLength == 0)
					pw.setColor(x, y, Color.WHITE);
				else {
					if ((i) % dashLength == 0)
						drawDash = !drawDash;
					if (drawDash == true)
						pw.setColor(x, y, Color.WHITE);
				}
				
				x += 1;
				
				if(x >= end.getX())
					break;
					
				i++;
			} while(true);
		}
		//vertical
		else if(diffX == 0) {
		
			do {
			
				if (dashLength == 0)
					pw.setColor(x, y, Color.WHITE);
				else {
					if ((i) % dashLength == 0)
						drawDash = !drawDash;
					if (drawDash == true)
						pw.setColor(x, y, Color.WHITE);
				}
				
				y += 1;
				
				if(y >= end.getY())
					break;
					
				i++;
			} while(true);
		}
		//positive slope less than one
		else if(slope > 0 && Math.abs(slope) < 1) {
		
			err = 2*(diffY - diffX);
			inc1 = 2*diffY;
			inc2 = 2*(diffY - diffX);
			
			do {
			
				if (dashLength == 0)
					pw.setColor(x, y, Color.WHITE);
				else {
					if ((i) % dashLength == 0)
						drawDash = !drawDash;
					if (drawDash == true)
						pw.setColor(x, y, Color.WHITE);
				}
			
				if(err < 0) 
					err += inc1;
				else {
					y = y+1;
					err += inc2;
				}
				
				x += 1;
			
				if(x >= end.getX()) 
					break;
					
				i++;
			} while (true);
		}
		//negative slope less than one 
		else if(slope < 0 && Math.abs(slope) < 1){
			
			err = 2*(diffY - diffX);
			inc1 = 2*diffY;
			inc2 = 2*(diffY - diffX);
				
			do {
			
				if (dashLength == 0)
					pw.setColor(x, y, Color.WHITE);
				else {
					if ((i) % dashLength == 0)
						drawDash = !drawDash;
					if (drawDash == true)
						pw.setColor(x, y, Color.WHITE);
				}
				
				if(err < 0)
					err += inc1;
				else {
					y = y-1;
					err += inc2;
				}
				
				x += 1;
				
				if(x >= end.getX())
					break;
					
				i++;
			} while(true);
		}
		//positive slope greater than one
		else if(slope > 0 && Math.abs(slope) > 1) {
		
			err = 2*(diffX - diffY);
			inc1 = 2*diffX;
			inc2 = 2*(diffX - diffY);
				
			do {
					
				if (dashLength == 0)
					pw.setColor(x, y, Color.WHITE);
				else {
					if ((i) % dashLength == 0)
						drawDash = !drawDash;
					if (drawDash == true)
						pw.setColor(x, y, Color.WHITE);
				}
				
				if(err < 0)
					err += inc1;
				else {
					x = x+1;
					err += inc2;
				}
				
				y += 1;
				
				if(y >= end.getY())
					break;
					
				i++;
			} while(true);
		}
		//negative slope greater than one
		else if(slope < 0 && Math.abs(slope) > 1) {
		
			err = 2*(diffX - diffY);
			inc1 = 2*diffX;
			inc2 = 2*(diffX - diffY);
		
			do {
			
				if (dashLength == 0)
					pw.setColor(x, y, Color.WHITE);
				else {
					if ((i) % dashLength == 0)
						drawDash = !drawDash;
					if (drawDash == true)
						pw.setColor(x, y, Color.WHITE);
				}
				
				if(err < 0)
					err += inc1;
				else {
					x = x-1;
					err += inc2;
				}
				
				y += 1;
				
				if(y >= end.getY())
					break;
					
				i++;
			} while(true);
		}
				
		
	}//draw
	
	/**
	 * Clears the drawing area.
	 *
	 * @param canvas The drawing area
	 */
	public void clear(Canvas canvas) {
	
		gc = canvas.getGraphicsContext2D();
		gc.clearRect(0, 0, DisplayController.IMAGE_WIDTH, DisplayController.IMAGE_HEIGHT);
		
	}//clear
	
	public ArrayList<Line> clip(
		ArrayList<Line> lines, int vx0, int vy0, int vx1, int vy1,
		int wx0, int wy0, int wx1, int wy1) {
		
		double a = ((double)(vx1-vx0))/((double)(wx1-wx0));
		double b = vx0 - (double)(a*wx0);
		double c = ((double)(vy1-vy0))/((double)(wy1-wy0));
		double d = vy0 - (double)(c*wy0);
	
		ArrayList<Line> drawingLines = new ArrayList<Line>();
		byte c0, c1;
		int x0, y0, x1, y1;
		int xs0, ys0, xs1, ys1;
		
		for(int i = 0; i < lines.size(); i++) {
		
			x0 = lines.get(i).getStart().getX();
			y0 = lines.get(i).getStart().getY();
			x1 = lines.get(i).getEnd().getX();
			y1 = lines.get(i).getEnd().getY();
		
			//Start Point: setting c0
			if(x0 < vx0) {
			
				//left and above
				if(y0 < vy0) 
					c0 = (byte)0b00001001;
				//left and below
				else if(y0 > vy1)
					c0 = (byte)0b00000101;
				//just left
				else 
					c0 = (byte)0b00000001;
				
			}
			else if(x0 > vx1) {
			
				//right and above 
				if(y0 < vy0) 
					c0 = (byte)0b00001010;
				//right and below
				else if(y0 > vy1)
					c0 = (byte)0b00000110;
				//just right 
				else 
					c0 = (byte)0b00000110;
					
			}
			else {
			
				//just above 
				if(y0 < vy0)
					c0 = (byte)0b00001000;
				//just below
				else if (y0 > vy1)
					c0 = (byte)0b00001001;
				//in viewing area 
				else
					c0 = (byte)0b00000000;
				
			}
			
			//Ending Point: setting c1 
			if(x1 < vx0) {
			
				//left and above
				if(y1 < vy0) 
					c1 = (byte)0b00001001;
				//left and below
				else if(y1 > vy1)
					c1 = (byte)0b00000101;
				//just left
				else 
					c1 = (byte)0b00000001;
				
			}
			else if(x1 > vx1) {
			
				//right and above 
				if(y1 < vy0) 
					c1 = (byte)0b00001010;
				//right and below
				else if(y1 > vy1)
					c1 = (byte)0b00000110;
				//just right 
				else 
					c1 = (byte)0b00000110;
					
			}
			else {
			
				//just above 
				if(y1 < vy0)
					c1 = (byte)0b00001000;
				//just below
				else if (y1 > vy1)
					c1 = (byte)0b00001001;
				//in viewing area 
				else
					c1 = (byte)0b00000000;
				
			}
				
			//entirely visible. add line to list of lines to be drawn.	
			if((byte)(c0 | c1) == (byte)0b00000000) {
			
				xs0 = (int)(a*x0 + b);
				ys0 = (int)(c*y0 + d);
				xs1 = (int)(a*x1 + b);
				ys1 = (int)(c*y1 + d);
				
				drawingLines.add(
					new Line(
						new EndPoints2D(xs0, ys0),
						new EndPoints2D(xs1, ys1)
					)
				);
			}
			//entirely invisible. Do nothing.
			else if((byte)(c0 & c1) != (byte)0b00000000) {}
			//Need further calcs
			else {
			
			}
			
		}//for
		
		return drawingLines;
	}
		
}//LineDrawer