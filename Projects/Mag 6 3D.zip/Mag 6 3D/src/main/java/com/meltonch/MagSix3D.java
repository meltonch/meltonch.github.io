package com.meltonch;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Sapphire Basic is a basic 2D Graphics manipulation program. It's 
 * built using the javafx GUI toolkit, but the only built-in functionality
 * utilized as far as creating and manipulating graphics is the 
 * <code>setPixel</code> method in the <code>PixelWriter</code> interface.
 * All calculations are built from scratch. 
 * 
 * @author Chase Melton <meltonch@uga.edu>
 * @version Alpha 
 */
public class MagSix3D extends Application {
	
	/**
	 * The main method, where the program is launched.
	 */
	public static void main(String[] args) {
		Application.launch(MagSix3D.class, args);
	}// main
	
	/**
	 * Start method that handles setting up application details.
	 *
	 * @param stage the application stage 
	 * @throws ioe will throw an exception if the supplied fxml document can't be found or loaded.
	 */
	@Override
	public void start(Stage stage) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("/Display.fxml"));
		stage.setTitle("Mag 6 3D vA");
		
		Scene scene = new Scene(root, 1800, 900);
		
		stage.setScene(scene);
		stage.show();
	}// start 
	
}// Mag 6 3D