<?php

/**
 * The persistable interface describes the functions any 
 * object class MUST have in order to be a persistable object
 * (i.e., an object that can interact with a database). When creating an object,
 * its id should initially be set to -1. The functions in this interface should 
 * handle further manipulation of the id.
 *
 * @author Team NoName
 * @version 1.0
 */
interface persistable
{
	
	/**
	 * If an object has been stored in the database, it will have 
	 * received an id. This function acts as a way to retrieve that id.
	 * If the object can't be found, -1 is returned.
	 * 
	 * @return The id of the calling object
	 */
	public function getId();	

	/**
	 * Sets the id for an object. Typically used when creating an object
	 * that will be used to update an existing entry in the database.
	 *
	 * @param $id The id to assign to an object
	 */
	public function setId($id);

	/**
	 * Check to see whether or not an object has already been created, i.e.
	 * stored for the first time.
	 *
	 * @return true if the object has already been created.
	 */
	public function isPersistent();

}

?>
	
