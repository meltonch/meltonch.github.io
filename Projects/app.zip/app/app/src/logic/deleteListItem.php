<?php

$win_path = 'C:\xampp\htdocs\app\\';
$lin_path = 'home/chase/public_html/app/';
set_include_path(get_include_path() . PATH_SEPARATOR . $win_path . PATH_SEPARATOR . $lin_path);

require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'listItem.php'; 
require_once 'src' . DIRECTORY_SEPARATOR . 'layer' . DIRECTORY_SEPARATOR . 'PersistenceLayer.php';

//create and check connection
$conn = new mysqli('localhost', 'app', 'app', 'app');

if($conn->connect_error)
{
	die("Connection Failed: " . $conn->connect_error);
}

//Create a PersistenceLayer with our connection
$pLayer = new PersistenceLayer($conn);

//get list item info via post
if(isset($_POST['displayItem']))
{
	$item = $_POST['displayItem'];
}
else
{
	header("Location: http://localhost/app/main.php");
	$conn->close();
	exit();
}

foreach($item as $id)
{
	
	$result = $pLayer->deleteListItem($id);
	
	if($result != 0) break;
	
}

if(gettype($result) == 'integer')
{
	header("Location: http://localhost/app/main.php");
}
else
{
	echo "Something Broke! Oh Noes!!!!!";
}

$conn->close();

?>