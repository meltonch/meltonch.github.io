<?php

$win_path = 'C:\xampp\htdocs\app\\';
$lin_path = 'home/chase/public_html/app/';
set_include_path(get_include_path() . PATH_SEPARATOR . $win_path . PATH_SEPARATOR . $lin_path);

require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'calendarItem.php'; 
require_once 'src' . DIRECTORY_SEPARATOR . 'layer' . DIRECTORY_SEPARATOR . 'PersistenceLayer.php';

//create and check connection
$conn = new mysqli('localhost', 'app', 'app', 'app');

if($conn->connect_error)
{
	die("Connection Failed: " . $conn->connect_error);
}

//Create a PersistenceLayer with our connection
$pLayer = new PersistenceLayer($conn);

//get list item info via post
if(isset($_POST['id']))
{
	$result = $pLayer->deleteCalendarItem($_POST['id']);
}
else
{
	header("Location: http://localhost/app/main.php");
	$conn->close();
	exit();
}


if($result == 0)
{
	header("Location: http://localhost/app/main.php");
}
else
{
	die("Something Broke! Oh Noes!!!!!");
}

$conn->close();

?>