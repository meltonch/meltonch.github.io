<?php

$win_path = 'C:\xampp\htdocs\app\\';
$lin_path = 'home/chase/public_html/app/';
set_include_path(get_include_path() . PATH_SEPARATOR . $win_path . PATH_SEPARATOR . $lin_path);

require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'listItem.php'; 
require_once 'src' . DIRECTORY_SEPARATOR . 'layer' . DIRECTORY_SEPARATOR . 'PersistenceLayer.php';

//create and check connection
$conn = new mysqli('localhost', 'app', 'app', 'app');

if($conn->connect_error)
{
	die("Connection Failed: " . $conn->connect_error);
}

//Create a PersistenceLayer with our connection
$pLayer = new PersistenceLayer($conn);

//get list item info via post
$listid = $_POST['list_id'];
$description = $_POST['item_add'];

$listItem = new ListItem($listid, $description);

$result = $pLayer->createListItem($listItem);

if(gettype($result) == 'integer')
{
	header("Location: http://localhost/app/main.php");
}
else
{
	echo "Something Broke! Oh Noes!!!!!";
}

$conn->close();

?>