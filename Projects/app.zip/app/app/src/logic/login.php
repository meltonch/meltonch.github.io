<?php

$win_path = 'C:\xampp\htdocs\app\\';
$lin_path = 'home/chase/public_html/app/';
set_include_path(get_include_path() . PATH_SEPARATOR . $win_path . PATH_SEPARATOR . $lin_path);

require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'user.php';
require_once 'src' . DIRECTORY_SEPARATOR . 'layer' . DIRECTORY_SEPARATOR . 'PersistenceLayer.php';

//create and check connection
$conn = new mysqli('localhost', 'app', 'app', 'app');

if($conn->connect_error)
{
	die("Connection Failed: " . $conn->connect_error);
}

//Create a PersistenceLayer with our connection
$pLayer = new PersistenceLayer($conn);

//Use our Persistence Layer to query the database for a user
$username = $_POST['username'];
$password = $_POST['password'];

$newUser = $pLayer->restoreUser($username, $password);

if(gettype($newUser) == 'integer')
{
	if($newUser == -1) echo 'No users found. Please go back and try again!';
	else if($newUser == -2) echo 'unexpected error.';
}
else
{
	session_start();

	$user_array = array(
		$newUser->getId(),
		$newUser->getUsername(),
		$newUser->getPassword(),
		$newUser->getFirst(),
		$newUser->getLast()
	);

	$_SESSION["user"] = $user_array;
	
	//redirect address
	header("Location: http://localhost/app/main.php");
	
}

$conn->close();

?>
