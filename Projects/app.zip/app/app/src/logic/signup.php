<?php

$win_path = 'C:\xampp\htdocs\app\\';
$lin_path = 'home/chase/public_html/app/';
set_include_path(get_include_path() . PATH_SEPARATOR . $win_path . PATH_SEPARATOR . $lin_path);

require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'user.php';
require_once 'src' . DIRECTORY_SEPARATOR . 'layer' . DIRECTORY_SEPARATOR . 'PersistenceLayer.php';

//create and check connection
$conn = new mysqli('localhost', 'app', 'app', 'app');

if($conn->connect_error)
{
	die("Connection Failed: " . $conn->connect_error);
}

//Create a PersistenceLayer with our connection
$pLayer = new PersistenceLayer($conn);

//Use our Persistence Layer to query the database for a user
$newUser = new User(
	$username = $_POST['username'],
	$password = $_POST['password'],
	$first = $_POST['first'],
	$last = $_POST['last']
);

$newId = $pLayer->createUser($newUser);

if(gettype($newId) == 'integer')
{

	$newUser->setId($newId);

	session_start();

	$user_array = array(
		$newUser->getId(),
		$newUser->getUsername(),
		$newUser->getPassword(),
		$newUser->getFirst(),
		$newUser->getLast()
	);

	$_SESSION["user"] = $user_array;

	header("Location: http://localhost/app/main.php");

}
else
{
	echo $newId;
}

$conn->close();

?>
