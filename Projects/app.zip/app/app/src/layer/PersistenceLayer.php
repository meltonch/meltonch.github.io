<?php

$win_path = 'C:\xampp\htdocs\app\\';
$lin_path = 'home/chase/public_html/app/';
set_include_path(get_include_path() . PATH_SEPARATOR . $win_path . PATH_SEPARATOR . $lin_path);


require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'calendar.php'; //Windows
require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'calendarItem.php'; //Windows
require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'list.php'; //Windows
require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'listItem.php'; //Windows
require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'user.php'; //Windows


/**
 * PersistenceLayer is intended to be an abstraction between the normal usage of the system 
 * objects (user, calendar, etc.) and their interactions with the database. It is meant to 
 * center all of the sql and other necessary database interactions in one place. Each object 
 * has four interaction functions (with the exception of user, for which there is no delete function):
 * restore, which retrieves an existing object from the database; create, which adds a new entry 
 * into the database; update, which updates values of an existing entry in the database; and 
 * delete, which removes an existing entry from the database.
 * 
 * @author Team NoName
 * @version 1.0
 */
class PersistenceLayer
{
	private $conn = null;
	
	private $restoreUserSql = "select * from user where username = ? and password = ?";
	private $updateUserSql = "update user set password = ?, first = ?, last = ? where id = ?";
	private $createUserSql = "insert into user (username, password, first, last) 
				values(?, ?, ?, ?)";
	private $restoreCalendarSql = "select * from calendar where userid = ?";
	private $createCalendarSql = "insert into calendar (userid, name, visible) values(?, ?, ?)";
	private $updateCalendarSql = "update calendar set name = ?, visible = ? where id = ?";
	private $deleteCalendarSql = "delete from calendar where id = ?";
	private $restoreCalendarItemSql = "select * from calendaritem where calendarid = ?";
	private $createCalendarItemSql = "insert into calendaritem (calendarid, name, description, location, time)
									values(?, ?, ?, ?, ?)";
	private $updateCalendarItemSql = "update calendaritem set name = ?, description = ?, location = ?, time = ?
									where id = ?";
	private $deleteCalendarItemSql = "delete from calendaritem where id = ?";
	private $restoreUserListSql = "select * from list where userid = ?";
	private $createUserListSql = "insert into list (userid, name, description) values(?, ?, ?)";
	private $updateUserListSql = "update list set name = ?, description = ? where id = ?";
	private $deleteUserListSql = "delete from list where id = ?";
	private $restoreListItemSql = "select * from listitem where listid = ?";
	private $createListItemSql = "insert into listitem (listid, description) values(?, ?)";
	private $updateListItemSql = "update listitem set description = ? where id = ?";
	private $deleteListItemSql = "delete from listitem where id = ?";


	/**
	 * Constructs a PersistenceLayer object. The only parameter should be a 
	 * valid connection- PersistenceLayer does NOT handle details of setting up
	 * or closing a connection. It interacts with the database assuming a valid
	 * connection.
	 */
	function __construct($conn)	
	{ 
		$this->conn = $conn;
	}

	/**
	 * Returns an existing user object from the database given a username and 
	 * a password. If an entry can't be found matching the username, or the password
	 * is incorrect, restoreUser will return -1. If multiple entries are found that
	 * match the username, restoreUser will return -2. (This should never happen, as 
	 * the username parameter must be unique within the database.) If there is an error
	 * somewhere in the process of interacting with the database, -3 is returned.
	 *
	 * @param $username the username that will be used to search the database.
	 * @param $password the password to be checked against the username.
	 * @return $userObj a user object created from database information, -1 if not found.
	 */
	function restoreUser($username, $password)
	{		
		
		if(!($stmt = $this->conn->prepare($this->restoreUserSql)))
		{
			return -3;
		}

		if(!($stmt->bind_param('ss', $username, $password)))
		{
			return -3;
		}
		
		if(!$stmt->execute())
		{
			return -3;
		}

		$stmt->store_result();

		$stmt->bind_result($id, $name, $pass, $first, $last);

		if($stmt->num_rows == 0) return -1;
		if($stmt->num_rows > 1) return -2;

		if (!$stmt->fetch()) return -3;
		else
		{	
			$userObj = new User($name, $pass, $first, $last);
			$userObj->setId($id);
			return $userObj;
		}


	}//restoreUser

	/**
	 * Stores (creates) a new user object into the user table and returns the
	 * auto-generated ID. If the entry already exists, returns an error message
	 * as a string and does not create a new entry.
	 *
	 * @param $user a user object to be created in the database.
	 * @return mixed int if creation is successful, string if not
	 */
	function createUser($user)
	{

		if(!($stmt = $this->conn->prepare($this->createUserSql)))
		{
			return -1 . " Prepare Issues";
		}

		$username = $user->getUsername();
		$password = $user->getPassword();
		$first = $user->getFirst();
		$last = $user->getLast();

		if(!($stmt->bind_param('ssss', $username, $password, $first, $last)))
		{
			return -1 . " Bind issues";
		}

		
		if(!$stmt->execute())
		{
			$errstmt = -3 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return $stmt->insert_id;


	}

	/**
	 * Updates an existing user in the database using the provided user object.
	 * Searches the database by id only. Returns 0 if successful, -1 if not.
	 *
	 * @param $user the provided user object with which to update an existing entry.
	 * @return mixed 0 if successful, -1 plus error message if not.
	 */
	function updateUser($user)
	{

		if(!($stmt = $this->conn->prepare($this->updateUserSql)))
		{
			return -1 . " Prepare Issues";
		}

		$password = $user->getPassword();
		$first = $user->getFirst();
		$last = $user->getLast();
		$username = $user->getUsername();

		if(!($stmt->bind_param('ssss', $password, $first, $last, $username)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -1 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return 0;

	}

	/**
	 * Returns an array of calendar objects from the database based on the id of the 
	 * given user object.
	 *
	 * @param $user the owner of the calendars to be returned.
	 * @return $calendarArray an array of calendar objects from the database
	 */
	function restoreCalendar($user)
	{

		if(!($stmt = $this->conn->prepare($this->restoreCalendarSql)))
		{
			return -3 . " Prepare Issues";
		}

		$uid = $user->getId();

		if(!($stmt->bind_param('i', $uid)))
		{
			return -3 . " Bind Issues";
		}
		
		if(!$stmt->execute())
		{
			return -3 . ' ' . $stmt->errno . ' ' . $stmt->error;
		}

		$stmt->store_result();

		$stmt->bind_result($id, $userid, $name, $visible);

		if($stmt->num_rows == 0) return -1;

		if (!$stmt->fetch()) return -3;
		else
		{	
			$result = array();
			$i = 0;
		
			do {

				$result[$i] = new Calendar($userid, $name, $visible);
				$result[$i]->setId($id);

				$i++;

			} while($stmt->fetch());

			return $result;
				
		}//else

	}//restoreCalendar

	/**
	 * Stores (creates) a new calendar into the calendar table. Requires a user object 
	 * and a calendar object to obtain the necessary information. Returns the id of the
	 * newly inserted calendar object if successful, or -1 plus an error message if not.
	 *
	 * @param $user needed for the userid.
	 * @param $calendar the calendar to be created.
	 * @return mixed database id of created calendar if successful, string if not
	 */
	function createCalendar($calendar)
	{

		if(!($stmt = $this->conn->prepare($this->createCalendarSql)))
		{
			return -1 . " Prepare Issues";
		}

		$userid = $calendar->getUserid();
		$name = $calendar->getName();
		$visible = $calendar->getVisible();

		if(!($stmt->bind_param('isi', $userid, $name, $visible)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -3 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return $stmt->insert_id;

	}

	/**
	 * Updates an existing calendar in the database using the provided calendar object.
	 * Searches by id only. Returns 0 if successful, -1 if not.
	 * 
	 * @param $calendar the calendar object to update.
	 * @return mixed 0 if successful, string if not.
	 */
	function updateCalendar($calendar)
	{

		if(!($stmt = $this->conn->prepare($this->updateCalendarSql)))
		{
			return -1 . " Prepare Issues";
		}

		$name = $calendar->getName();
		$visible = $calendar->getVisible();
		$id = $calendar->getId();

		if(!($stmt->bind_param('sii', $name, $visible, $id)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -1 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return 0;

	}

	/**
	 * Deletes a Calendar from the database. Searches by calendar id only. Returns 0 if 
	 * successful, -1 if not.
	 * 	
	 * @param $calendar the calendar object to delete from the database.
	 * @return mixed 0 if successful, string if not
	 */
	function deleteCalendar($calendar)
	{

		if(!($stmt = $this->conn->prepare($this->deleteCalendarSql)))
		{
			return -1 . " Prepare Issues";
		}

		$id = $calendar->getId();

		if(!($stmt->bind_param('i', $id)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -1 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return 0;

	}
	
	/**
	 * Returns an arraay of calendar item objects corresponding to the provided
	 * calendar object. Calendar item table is searched for entries with a 
	 * calendar id corresponding to the id of the provided calendar. Returns -1
	 * and an error message if unsuccessful.
	 *
	 * @param $calendar the calendar with which events will be searched for
	 * @return mixed array of calendaritem objects if successful, -1 if not
	 */
	function restoreCalendarItem($calendar)
	{
		if(!($stmt = $this->conn->prepare($this->restoreCalendarItemSql)))
		{
			return -3 . " Prepare Issues";
		}

		$cid = $calendar->getId();

		if(!($stmt->bind_param('i', $cid)))
		{
			return -3 . " Bind Issues";
		}
		
		if(!$stmt->execute())
		{
			return -3 . ' ' . $stmt->errno . ' ' . $stmt->error;
		}

		$stmt->store_result();

		$stmt->bind_result($id, $calendarid, $name, $description, $location, $time);

		if($stmt->num_rows == 0) return -1;

		if (!$stmt->fetch()) return -3;
		else
		{	
			$result = array();
			$i = 0;
		
			do {

				$result[$i] = new CalendarItem($calendarid, $name, $description, $location, $time);
				$result[$i]->setId($id);

				$i++;

			} while($stmt->fetch());

			return $result;
				
		}//else
			
	}//restoreCalendarItem
	
	/**
	 * Stores (creates) a new calendar item object in the database. Uses values from the provided
	 * calendarItem object. Returns the database ID of the new entry if successful, -1 plus an 
	 * error message if not.
	 *
	 * @param $calendarItem the calendarItem to store in the database
	 * @return mixed the database id of the new entry if successful, -1 plus an error message if not
	 */
	function createCalendarItem($calendarItem)
	{
		
		if(!($stmt = $this->conn->prepare($this->createCalendarItemSql)))
		{
			return -1 . " Prepare Issues";
		}

		$calendarid = $calendarItem->getCalendarid();
		$name = $calendarItem->getName();
		$description = $calendarItem->getDescription();
		$location = $calendarItem->getLocation();
		$time = $calendarItem->getTime();

		if(!($stmt->bind_param('issss', $calendarid, $name, $description, $location, $time)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -3 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return $stmt->insert_id;
		
	}
	
	/**
	 * Updates an existing calendarItem entry in the database. Searches by the id of the 
	 * provided calendaritem object. Returns 0 if successful, -1 plus an error message if not.
	 *
	 * @param $calendarItem the calendarItem object to be updated.
	 * @return mixed 0 if successful, -1 plus error message if not.
	 */
	function updateCalendarItem($calendarItem)
	{
		
		if(!($stmt = $this->conn->prepare($this->updateCalendarItemSql)))
		{
			return -1 . " Prepare Issues";
		}

		$name = $calendarItem->getName();
		$description = $calendarItem->getDescription();
		$location = $calendarItem->getLocation();
		$time = $calendarItem->getTime();
		$id = $calendarItem->getId();

		if(!($stmt->bind_param('ssssi', $name, $description, $location, $time, $id)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -1 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return 0;
		
	}
	
	/**
	 * Deletes an existing calendaritem object from the database. Returns 0 
	 * if successful, -1 plus an error message if not.
	 *
	 * @param $calendarItem the calendarItem to be deleted.
	 * @return mixed 0 if successful, -1 plus an error message if not.
	 */
	function deleteCalendarItem($calendarItemId)
	{
		
		if(!($stmt = $this->conn->prepare($this->deleteCalendarItemSql)))
		{
			return -1 . " Prepare Issues";
		}

		if(!($stmt->bind_param('i', $calendarItemId)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -1 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return 0;
		
	}
	
	/**
	 * Returns an array of UserList objects corresponding to the userid of the 
	 * provided user object. If no UserList objects are found or an error occurs,
	 * returns -1 plus an error message.
	 *
	 * @param $user the user with which userlists will be searched for
	 * @return mixed array of userlists if successful, -1 and error if not 
	 */
	function restoreUserList($user)
	{
		
		if(!($stmt = $this->conn->prepare($this->restoreUserListSql)))
		{
			return -3 . " Prepare Issues";
		}

		$uid = $user->getId();

		if(!($stmt->bind_param('i', $uid)))
		{
			return -3 . " Bind Issues";
		}
		
		if(!$stmt->execute())
		{
			return -3 . ' ' . $stmt->errno . ' ' . $stmt->error;
		}

		$stmt->store_result();

		$stmt->bind_result($id, $userid, $name, $description);

		if($stmt->num_rows == 0) return -1;

		if (!$stmt->fetch()) return -3;
		else
		{	
			$result = array();
			$i = 0;
		
			do {

				$result[$i] = new UserList($userid, $name, $description);
				$result[$i]->setId($id);

				$i++;

			} while($stmt->fetch());

			return $result;
				
		}//else
			
	}//restoreUserList
	
	/**
	 * Stores (creates) a new userlist into the list table. Requires a user object 
	 * and a userlist object to obtain the necessary information. Returns the id of the
	 * newly inserted userlist object if successful, or -1 plus an error message if not.
	 *
	 * @param $user needed for the userid.
	 * @param $userList the userlist to be created.
	 * @return mixed database id of created userlist if successful, string if not
	 */
	function createUserList($userList)
	{

		if(!($stmt = $this->conn->prepare($this->createUserListSql)))
		{
			return -1 . " Prepare Issues";
		}

		$userid = $userList->getUserid();
		$name = $userList->getName();
		$description = $userList->getDescription();

		if(!($stmt->bind_param('sss', $userid, $name, $description)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -3 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return $stmt->insert_id;

	}
	
	/**
	 * Updates an existing userlist in the database using the provided userlist object.
	 * Searches by id only. Returns 0 if successful, -1 if not.
	 * 
	 * @param $userList the userList object to update.
	 * @return mixed 0 if successful, string if not.
	 */
	function updateUserList($userList)
	{

		if(!($stmt = $this->conn->prepare($this->updateUserListSql)))
		{
			return -1 . " Prepare Issues";
		}

		$name = $userList->getName();
		$description = $userList->getDescription();
		$id = $userList->getId();

		if(!($stmt->bind_param('ssi', $name, $description, $id)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -1 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return 0;

	}
	
	/**
	 * Deletes a userlist from the database. Searches by userlist id only. Returns 0 if 
	 * successful, -1 if not.
	 * 	
	 * @param $userList the userlist object to delete from the database.
	 * @return mixed 0 if successful, string if not
	 */
	function deleteUserList($userList)
	{

		if(!($stmt = $this->conn->prepare($this->deleteUserListSql)))
		{
			return -1 . " Prepare Issues";
		}

		$id = $userList->getId();

		if(!($stmt->bind_param('i', $id)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -1 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return 0;

	}
	
	/**
	 * Returns an array of listitem objects corresponding to the provided
	 * userlist object. list item table is searched for entries with a 
	 * list id corresponding to the id of the provided user list. Returns -1
	 * and an error message if unsuccessful.
	 *
	 * @param $userList the userList with which list items will be searched for
	 * @return mixed array of calendaritem objects if successful, -1 if not
	 */
	function restoreListItem($userList)
	{
		if(!($stmt = $this->conn->prepare($this->restoreListItemSql)))
		{
			return -3 . " Prepare Issues";
		}

		$lid = $userList->getId();

		if(!($stmt->bind_param('i', $lid)))
		{
			return -3 . " Bind Issues";
		}
		
		if(!$stmt->execute())
		{
			return -3 . ' ' . $stmt->errno . ' ' . $stmt->error;
		}

		$stmt->store_result();

		$stmt->bind_result($id, $listid, $description);

		if($stmt->num_rows == 0) return -1;

		if (!$stmt->fetch()) return -3;
		else
		{	
			$result = array();
			$i = 0;
		
			do {

				$result[$i] = new ListItem($listid, $description);
				$result[$i]->setId($id);

				$i++;

			} while($stmt->fetch());

			return $result;
				
		}//else
			
	}//restoreListItem
	
	/**
	 * Stores (creates) a new list item object in the database. Uses values from the provided
	 * list object. Returns the database ID of the new entry if successful, -1 plus an 
	 * error message if not.
	 *
	 * @param $listItem the listItem to store in the database
	 * @return mixed the database id of the new entry if successful, -1 plus an error message if not
	 */
	function createListItem($listItem)
	{
		
		if(!($stmt = $this->conn->prepare($this->createListItemSql)))
		{
			return -1 . " Prepare Issues";
		}

		$listid = $listItem->getListid();
		$description = $listItem->getDescription();

		if(!($stmt->bind_param('is', $listid, $description)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -3 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return $stmt->insert_id;
		
	}
	
	/**
	 * Updates an existing listItem entry in the database. Searches by the id of the 
	 * provided listitem object. Returns 0 if successful, -1 plus an error message if not.
	 *
	 * @param $listItem the listItem object to be updated.
	 * @return mixed 0 if successful, -1 plus error message if not.
	 */
	function updateListItem($listItem)
	{
		
		if(!($stmt = $this->conn->prepare($this->updateCalendarItemSql)))
		{
			return -1 . " Prepare Issues";
		}

		$name = $calendarItem->getName();
		$description = $calendarItem->getDescription();
		$location = $calendarItem->getLocation();
		$time = $calendarItem->getTime();

		if(!($stmt->bind_param('ssss', $name, $description, $location, $time)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -1 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return 0;
		
	}
	
	/**
	 * Deletes an existing listitem object from the database. Returns 0 
	 * if successful, -1 plus an error message if not. Searches based on 
	 * supplied listItem ID.
	 *
	 * @param $listItem the listItem to be deleted.
	 * @return mixed 0 if successful, -1 plus an error message if not.
	 */
	function deleteListItem($id)
	{
		
		if(!($stmt = $this->conn->prepare($this->deleteListItemSql)))
		{
			return -1 . " Prepare Issues";
		}

		if(!($stmt->bind_param('i', $id)))
		{
			return -1 . " Bind issues";
		}

		if(!$stmt->execute())
		{
			$errstmt = -1 . ' ' . $stmt->errno . ' ' . $stmt->error;
			return $errstmt;
		}

		return 0;
		
	}
		
}//PersistenceLayer

?>
		
		
