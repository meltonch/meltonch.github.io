var calendar_array = [];
var list_array = [];
var calendar_item_array = [];
var list_item_array = [];
var list_count = 0;
var user = [];

window.onload = function() 
{
	//get our user information supplied to main.html via php
	var user_p = document.getElementById("u");
	var data = user_p.textContent;
	user = JSON.parse(data);
	
	//personalize our greeting message
	if(user[3] != null) document.getElementById("name").innerHTML = "Hello, " + user[3];
	else document.getElementById("name").innerHTML = "Hello, " + user[1];
	
	//set a real date and add signout link
	var cur_date = new Date();
	document.getElementById("date").innerHTML = 
		cur_date.toDateString()  + 
		" | <a href=\"http://localhost/app/src/logic/signout.php\">Sign Out</a>"
	;
	
	//call populator functions to populate menus on the page
	populateCalendars();
	populateLists();
	populateCalendarItems();
	populateListItems();
	
	// populate the weather.
	var xmlhttp = new XMLHttpRequest();
    var url = "http://api.wunderground.com/api/47827c412482cbbe/conditions/q/GA/Athens.json";
        
    xmlhttp.onreadystatechange=function() {
                
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
		{
			getResponse(xmlhttp.responseText);
		}
    }
        
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
        
    function getResponse(response) {
        var arr = JSON.parse(response);
        console.log(arr);
        
        document.getElementById("currTemp").innerHTML = "" + arr.current_observation.temp_f;
        document.getElementById("weathericon").src = arr.current_observation.icon_url;
        document.getElementById("location").innerHTML =  "" + arr.current_observation.display_location.full;
        
        // document.write("Feels like: " + arr.current_observation.feelslike_f);
    }
	
	//add event listeners for "add new" menu items
	document.getElementById("list-add").addEventListener("click", addList);
	document.getElementById("calendar-add").addEventListener("click", addCalendar);
	
};//onload

function populateCalendars()
{
	
	var i = 0;			//loop iterator
	var cal_p;			//will hold reference to a paragraph element with calendar data
	var cal_string;		//will hold parsed information from the paragraph data
	var data;
	
	//while we can still find elements, parse the data, save it as a calendar, 
	//and push it to our array of calendars
	while((cal_p = document.getElementById('c' + i)) != null)
	{
		//get calendar data from main.php
		data = cal_p.textContent;
		cal_string = JSON.parse(data);
		
		console.log("Calendar: " + cal_string);

		calendar_array.push(
			new Calendar(
				cal_string[0],
				cal_string[1],
				cal_string[2],
				cal_string[3]
			)
		);

		i++;
	}

	//get reference to the parent node we will append to
	var cal_node = document.getElementById("calendar-content");
	var append_node;

	//create and append nodes that represent calendar menu items
	for(i = 0; i < calendar_array.length; i++)
	{
		append_node = document.createElement('div');
		append_node.innerHTML = calendar_array[i].getName();
		append_node.setAttribute("name", calendar_array[i].getId());
		append_node.addEventListener("click", createCalendar);
		cal_node.appendChild(append_node);
	}
	
}

function populateLists()
{
	
	//populate Lists menu
	var i = 0;
	var list_p;
	var list_string;
	var data;
	while((list_p = document.getElementById('l' + i)) != null)
	{
		//get list data from main.php
		data = list_p.textContent;
		list_string = JSON.parse(data);
		
		console.log("List: " + list_string);

		list_array.push(
			new UserList(
				list_string[0],
				list_string[1],
				list_string[2],
				list_string[3]
			)
		);

		i++;
	}

	var list_node = document.getElementById("list-content");

	for(i = 0; i < list_array.length; i++)
	{
		append_node = document.createElement('div');
		append_node.innerHTML = list_array[i].getName();
		
		//set attribute "name" to the list ID to use later
		append_node.setAttribute("name", list_array[i].getId());
		append_node.addEventListener("click", showList);
		list_node.appendChild(append_node);
	}
	
}

function populateCalendarItems()
{
	var j = 0;
	var cal_item_p;
	var cal_item_string;
	
	//We know how many calendars we have by now...
	for(var i = 0; i < calendar_array.length; i++)
	{
		//...but still not how many calendar items.
		while((cal_item_p = document.getElementById(
			'ci' + calendar_array[i].getId() + j
		)) != null)
		{
			data = cal_item_p.textContent;
			cal_item_string = JSON.parse(data);
			
			console.log("Calendar Item: " + cal_item_string);
			
			calendar_item_array.push(
				new CalendarItem(
					cal_item_string[0],
					cal_item_string[1],
					cal_item_string[2],
					cal_item_string[3],
					cal_item_string[4],
					cal_item_string[5]
				)
			);
			
			j++;
			
		}//while
		
		j = 0;
		
	}//for
	
}

function populateListItems()
{
	var j = 0;
	var list_item_p;
	var list_item_string;
	
	//We know how many lists we have by now...
	for(var i = 0; i < list_array.length; i++)
	{
		//...but still not how many list items.
		while((list_item_p = document.getElementById(
			'li' + list_array[i].getId() + j
		)) != null)
		{
			data = list_item_p.textContent;
			list_item_string = JSON.parse(data);
			
			console.log("List Item: " + list_item_string);
			
			list_item_array.push(
				new ListItem(
					list_item_string[0],
					list_item_string[1],
					list_item_string[2]
				)
			);
			
			j++;
			
		}//while
		
		j = 0;
		
	}//for
	
}

function listCalendars() 
{	
	document.getElementById("calendar-content").classList.toggle("show");
}

function listLists()
{
	document.getElementById("list-content").classList.toggle("show");
}

function showList() 
{
	
	list_count ++;
	
	//should set id to the id of the list
	var id = this.getAttribute("name");
	
	//retrieve the list we're working with from the list array
	var cur_list;
	for(var i = 0; i < list_array.length; i++)
	{
		if(list_array[i].getId() == id) cur_list = list_array[i];
	}
	
	//retrieve all associated list items
	var cur_items = [];
	for(var i = 0; i < list_item_array.length; i++)
	{
		if(list_item_array[i].getListid() == id)
			cur_items.push(list_item_array[i]);
	}
	
	var dash = document.getElementById("dashboard");
	
	//test creating a list display through javascript
	var list_parent = document.createElement('div');	 				 //start by creating root
	list_parent.setAttribute("id", "list-display" + id);		 //set its attributes
	list_parent.setAttribute("class", "list-display");
	list_parent.setAttribute("draggable", true);
	list_parent.setAttribute("ondragstart", "drag(event)");
	
	dash.appendChild(list_parent);
	
	//Create a div for the list toolbar
	var list_toolbar = document.createElement('div');	 
	list_toolbar.setAttribute("class", "display-tools"); 
	
	//create a paragraph for the list name to add to the toolbar
	var list_name = document.createElement('p');		 
	list_name.setAttribute("id", "list-name");
	list_name.innerHTML = cur_list.getName();
	
	//create a minimize button to add to the toolbar
	var list_min = document.createElement('button');	
	list_min.setAttribute("class", "toolmin");
	list_min.innerHTML = '-';
	
	var list_add = document.createElement('button');	 
	list_add.setAttribute("class", "toolmin");
	list_add.setAttribute("id", id);
	list_add.innerHTML = '+';
	list_add.addEventListener("click", addListItem);
	
	//create a close button to add to the toolbar
	var list_close = document.createElement('button');	 
	list_close.setAttribute("class", "toolmin");
	list_close.setAttribute("id", id);
	list_close.innerHTML = 'X';
	list_close.addEventListener("click", removeList);
	
	//add name and buttons to the toolbar
	list_toolbar.appendChild(list_name);				 
	list_toolbar.appendChild(list_close);		
	list_toolbar.appendChild(list_min);
	list_toolbar.appendChild(list_add);
	
	//add the toolbar to the parent
	list_parent.appendChild(list_toolbar);				
	
	//create a paragraph for the list description
	var description = document.createElement('p');
	description.setAttribute("id", "list-describe");
	description.innerHTML = cur_list.getDescription();
	
	//add description to the parent
	list_parent.appendChild(description);
	
	//create a form to house the list items
	var list_form = document.createElement('form');
	list_form.setAttribute("id", "display-items");
	list_form.setAttribute("action", "src/logic/deleteListItem.php");
	list_form.setAttribute("method", "post");
	
	//create and add our actual list items to the form
	var list_label;
	var list_input;
	var id_pass;
	var br;
	for(var i = 0; i < cur_items.length; i++)
	{
		//create the text content of each item
		list_label = document.createElement('label');
		label_text = document.createTextNode(cur_items[i].getDescription());
	
		//create checkbox elements
		list_input = document.createElement('input');
		list_input.type = "checkbox";
		list_input.name = "displayItem[]";
		list_input.value = cur_items[i].getId();
	
		//create a line break
		br = document.createElement('br');
	
		//add text, checkbox, and line break to the label
		list_label.appendChild(list_input);
		list_label.appendChild(label_text);
		list_label.appendChild(br);
		
		//append label to the form
		list_form.appendChild(list_label);
	}
	
	//create a submit button
	var list_submit = document.createElement('input');
	list_submit.setAttribute("type", "submit");
	list_submit.setAttribute("class", "toolbtn");
	list_submit.setAttribute("value", "Update");
	
	//add submit button to form
	list_form.appendChild(list_submit);
	
	//append the form to the parent
	list_parent.appendChild(list_form);
	
}

function createCalendar() 
{
	var id = this.getAttribute("name");
	
	//retrieve the list we're working with from the list array
	var cur_cal;
	for(var i = 0; i < calendar_array.length; i++)
	{
		if(calendar_array[i].getId() == id) cur_cal = calendar_array[i];
	}
	
	//retrieve all associated list items
	var cur_items = [];
	for(var i = 0; i < calendar_item_array.length; i++)
	{
		if(calendar_item_array[i].getCalendarid() == id)
			cur_items.push(calendar_item_array[i]);
	}
	
	//get dashboard element
	var dash = document.getElementById("dashboard");
	
	//create cal-listcontainer
	var clc = document.createElement("div");
	clc.setAttribute("id", "cal-listcontainer" + id);
	clc.setAttribute("class", "cal-listcontainer");
	clc.setAttribute("draggable", true);
	clc.setAttribute("ondragstart", "drag(event)");
	
	dash.appendChild(clc);
	
	//create calcontainer
	var cc = document.createElement("div");
	cc.setAttribute("id", "calcontainer");
	cc.setAttribute("class", "calcontainer");
	
	clc.appendChild(cc);
	
	//create calendar table
	var cal = document.createElement("table");
	cal.setAttribute("id", "calendar");
	
	cc.appendChild(cal);
	
	// script will build the table automatically.  Yeah, right.
	// declare variables
	var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
	var monthname = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	var date = new Date();

	// alright, get the table.
	//var cal = document.getElementById("calendar");

	//Give it a toolbar
	var cal_toolbar = document.createElement('div');	 
	cal_toolbar.setAttribute("class", "display-tools"); 
	
	//create a paragraph for the list name to add to the toolbar
	var cal_name = document.createElement('p');		 
	cal_name.setAttribute("id", "list-name");
	cal_name.innerHTML = cur_cal.getName();
	
	//create a minimize button to add to the toolbar
	var cal_min = document.createElement('button');	
	cal_min.setAttribute("class", "toolmin");
	cal_min.innerHTML = '-';
	
	//create a close button to add to the toolbar
	var cal_close = document.createElement('button');	 
	cal_close.setAttribute("class", "toolmin");
	cal_close.setAttribute("id", id);
	cal_close.innerHTML = 'X';
	cal_close.addEventListener("click", removeCalendar);
	
	//create a button to add events
	var cal_add = document.createElement('button');	 
	cal_add.setAttribute("class", "toolmin");
	cal_add.setAttribute("id", id);
	cal_add.setAttribute("name", "create");
	cal_add.innerHTML = '+';
	cal_add.addEventListener("click", addCalendarItem);
	
	//create a button to open weekly view
	var cal_week = document.createElement('button');	 
	cal_week.setAttribute("class", "toolmin");
	cal_week.setAttribute("id", id);
	cal_week.innerHTML = 'Show Week';
	cal_week.addEventListener("click", showWeekly);
	
	//add name and buttons to the toolbar
	cal_toolbar.appendChild(cal_name);				 
	cal_toolbar.appendChild(cal_close);				
	cal_toolbar.appendChild(cal_min);
	cal_toolbar.appendChild(cal_add);
	cal_toolbar.appendChild(cal_week);
	
	// create the header.
	var header = cal.createTHead();
	var toolrow = header.insertRow(0);
	var toolcell = toolrow.insertCell(0);
	toolcell.appendChild(cal_toolbar);
	var titlerow = header.insertRow(1);
	var cell = titlerow.insertCell(0);

	// set the month and year 
	cell.innerHTML= monthname[date.getMonth()] + " " + date.getFullYear();
	cell.setAttribute("id", "month");
	cell.setAttribute("colspan", "7");


	// insert days of week.
	titlerow = header.insertRow(2);
	for (var d = 0; d < 7; d++)
	{
		cell = titlerow.insertCell(d);
		cell.innerHTML = weekdays[d];
		cell.setAttribute("class", "dayname");
	}

	var row = null;
	var firstday = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
	console.log("Firstday = " + firstday);
	var lastday = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
	console.log("lastday = " + lastday);

	var currDate = 1;
	var printdates = false;

	// insert days on calendar.
	for (var i = 0; i < 5; i++) 
	{
		// insert a new row.
		row = cal.insertRow();

		// insert day cells.
		for(var j = 0; j < 7; j++) 
		{
			cell = row.insertCell(j);
			cell.setAttribute("class", "day");
			


			var detailTable = document.createElement("table");
			detailTable.setAttribute("class", "daydetail");
			var detailrow = detailTable.insertRow();
			var detCell = detailrow.insertCell(0);
			detCell.setAttribute("class", "spacer");
			var detCell = detailrow.insertCell(1);
			detCell.setAttribute("class", "spacer");
			var detCell = detailrow.insertCell(2);
			detCell.setAttribute("class", "caldate");

			// optionally set the date.
			if ( ( i == 0 && j == firstday ) || (printdates == true && currDate <= lastday) ) 
			{
				detCell.innerHTML = "" + currDate;
				printdates = true;
				currDate++;
				
		
			}//if

			// insert 2 more rows 
			detailTable.insertRow();
			detailTable.insertRow();
			cell.appendChild(detailTable);
			
			//check to see if any events correspond to this date
			for(var k = 0; k < cur_items.length; k++)
			{
				//convert the time of our event into a format
				//we can easily work with
				var t = cur_items[k].getTime();
				event_time = t.replace(/\s/, "T");
				var event_date = new Date(event_time);
					
				if((event_date.getFullYear() == date.getFullYear()) &&
					(event_date.getMonth() == date.getMonth()) &&
					(event_date.getDate() + 1 == currDate))
					{
						var event_detail = document.createElement('div');
						event_detail.setAttribute("class", "event_detail");
						event_detail.setAttribute("id", cur_items[k].getId());
						event_detail.setAttribute("name", id);
						event_detail.addEventListener("click", showEventDetail);
						
						var timeOffset = event_date.getTimezoneOffset() / 60;
						
						event_detail.innerHTML = (event_date.getHours() + timeOffset) + ":" +
							event_date.getMinutes() + " " + cur_items[k].getName();
								
						cell.appendChild(event_detail);
					}//if
			}//for		

		}//for
	}//for
}

function showEventDetail()
{
	var id = this.getAttribute("id");
	var calendarid = this.getAttribute("name");
	
	var cur_event;
	for(var i = 0; i < calendar_item_array.length; i++)
	{
		if(calendar_item_array[i].getId() == id) 
		{
			cur_event = calendar_item_array[i];
			break;
		}
	}
	
	var dash = document.getElementById("dashboard");
	
	var add_container = document.createElement("div");
	add_container.setAttribute("id", "addWindow");
	add_container.setAttribute("class", "list-display");
	add_container.setAttribute("draggable", true);
	add_container.setAttribute("ondragstart", "drag(event)");
	
	dash.appendChild(add_container);
	
	var title = document.createElement("h2");
	title.innerHTML = "Event Details";
	
	var event_name = document.createElement('p');
	event_name.innerHTML = cur_event.getName();
	
	var event_desc = document.createElement('p');
	event_desc.innerHTML = cur_event.getDescription();
	
	var event_loc = document.createElement('p');
	event_loc.innerHTML = cur_event.getLocation();
	
	var event_time = document.createElement('p');
	event_time.innerHTML = cur_event.getTime();
	
	var br = document.createElement('br');
	
	var cancel = document.createElement("button");
	cancel.innerHTML = "Cancel";
	cancel.addEventListener("click", removeWindow);
	cancel.setAttribute("class", "toolbtn");
	
	var edit = document.createElement("button");
	edit.innerHTML = "Edit Event";
	edit.setAttribute("id", id);
	edit.setAttribute("name", calendarid);
	edit.addEventListener("click", updateCalendarItem);
	edit.setAttribute("class", "toolbtn");
	
	var del_form = document.createElement("form");
	del_form.setAttribute("action", "src/logic/deleteCalendarItem.php");
	del_form.setAttribute("method", "post");
	
	var id_pass = document.createElement("input");
	id_pass.type = "hidden";
	id_pass.name = "id";
	id_pass.value = id;
	
	var del = document.createElement("input");
	del.type = "submit";
	del.value = "Delete Event";
	del.setAttribute("class", "toolbtn");
	
	del_form.appendChild(id_pass);
	del_form.appendChild(del);
	
	add_container.appendChild(title);
	add_container.appendChild(event_name);
	add_container.appendChild(br);
	add_container.appendChild(event_desc);
	br = document.createElement('br');
	add_container.appendChild(br);
	add_container.appendChild(event_loc);
	br = document.createElement('br');
	add_container.appendChild(br);
	add_container.appendChild(event_time);
	br = document.createElement('br');
	add_container.appendChild(br);
	
	add_container.appendChild(edit);
	add_container.appendChild(cancel);
	add_container.appendChild(del_form);
	
}

function showWeekly()
{
	var id = this.getAttribute("id");
	
	//retrieve the list we're working with from the list array
	var cur_cal;
	for(var i = 0; i < calendar_array.length; i++)
	{
		if(calendar_array[i].getId() == id) cur_cal = calendar_array[i];
	}
	
	//retrieve all associated list items
	var cur_items = [];
	for(var i = 0; i < calendar_item_array.length; i++)
	{
		if(calendar_item_array[i].getCalendarid() == id)
			cur_items.push(calendar_item_array[i]);
	}
	
	//get our dashboard element
	var dash = document.getElementById("dashboard");
	
	//create weeklycontainer
	var wc = document.createElement("div");
	wc.setAttribute("id", "weeklycontainer" + id);
	wc.setAttribute("class", "weeklycontainer");
	wc.setAttribute("draggable", true);
	wc.setAttribute("ondragstart", "drag(event)");
	
	dash.appendChild(wc);
	
	//create weekdetail table
	var week = document.createElement("table");
	week.setAttribute("id", "weekdetail");
	
	wc.appendChild(week);
	
	// assemble the weekly detail schedule.
	// declare variables.
	var today = new Date();
	var dayOfWeek = today.getDay();
	var lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0); 
	var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

	console.log(today);
	console.log(dayOfWeek);
	console.log(lastDay);
	
	//build a toolbar
	var cal_toolbar = document.createElement('div');	 
	cal_toolbar.setAttribute("class", "display-tools"); 
	
	//create a paragraph for the list name to add to the toolbar
	var cal_name = document.createElement('p');		 
	cal_name.setAttribute("id", "list-name");
	cal_name.innerHTML = "Weekly: " + cur_cal.getName();
	
	//create a minimize button to add to the toolbar
	var cal_min = document.createElement('button');	
	cal_min.setAttribute("class", "toolmin");
	cal_min.innerHTML = '-';
	
	//create a close button to add to the toolbar
	var cal_close = document.createElement('button');	 
	cal_close.setAttribute("class", "toolmin");
	cal_close.setAttribute("id", id);
	cal_close.innerHTML = 'X';
	cal_close.addEventListener("click", removeWeeklyCalendar);
	
	//add name and buttons to the toolbar
	cal_toolbar.appendChild(cal_name);				 
	cal_toolbar.appendChild(cal_close);				
	cal_toolbar.appendChild(cal_min);

	// get the table, and build the header row.
	var toolrow = week.insertRow();
	var toolcell = toolrow.insertCell(0);
	toolcell.setAttribute("colspan", "2");
	toolcell.appendChild(cal_toolbar);
	var row = week.insertRow();
	var cell = row.insertCell(0);
	cell.setAttribute("colspan", "2");
	cell.setAttribute("class", "weekdays");

	// figure out the date for Saturday of this week.
	var satDate = today.getDate() + ( 7 - today.getDate());
	console.log(satDate);

	// compute the first day of the week's date.  Sunday.
	var sunDate = null;
	var sunMonth = null;
	if ((today.getDate() - today.getDay()) < 1) {
		var sunDay = new Date(today.getFullYear(), today.getMonth(), today.getDate() - today.getDay());
		sunMonth = sunDay.getMonth();
		sunDate = sunDay.getDate();
		console.log(sunDay);
	}
	else {
		sunDate = today.getDate() - today.getDay();
		sunMonth = today.getMonth();
	}

	console.log(sunDate);
	console.log("Month: " + sunMonth);
	// append these dates to header.
	cell.innerHTML = months[today.getMonth()] + " " + sunDate + " - " + months[today.getMonth()] + " " + satDate + ", " + today.getFullYear();


	for (var i = 0; i < 7; i++) {
		
		// add dates and calendar space.
		row = week.insertRow();
		cell = row.insertCell(0);
		cell.setAttribute("class", "weekdate");
		cell.innerHTML = "<span class=\"mon\">" + months[sunMonth].substring(0,3) + "</span><br /> " + (sunDate + i);
		// insert the cell that will contain events.
		cell = row.insertCell(1);
		cell.setAttribute("class", "daydetails");
		
		//check to see if any events correspond to this date
		for(var k = 0; k < cur_items.length; k++)
		{
			//convert the time of our event into a format
			//we can easily work with
			var t = cur_items[k].getTime();
			event_time = t.replace(/\s/, "T");
			var event_date = new Date(event_time);
					
			if((event_date.getFullYear() == new Date().getFullYear()) &&
				(event_date.getMonth() == sunMonth) &&
				(event_date.getDate() == sunDate + i))
				{
					var event_detail = document.createElement('div');
					event_detail.setAttribute("class", "event_detail");
					event_detail.setAttribute("id", cur_items[k].getId());
					event_detail.setAttribute("name", id);
					event_detail.addEventListener("click", showEventDetail);
						
					var timeOffset = event_date.getTimezoneOffset() / 60;
						
					event_detail.innerHTML = (event_date.getHours() + timeOffset) + ":" +
						event_date.getMinutes() + " " + cur_items[k].getName();
								
					cell.appendChild(event_detail);
				}//if
		}//for
	}
	
}

function removeList()
{
	var node;
	
	//check to see that the element to be removed exists
	if((node = document.getElementById("list-display" + this.id)) != null)
	{
		//remove all the node's children
		while(node.hasChildNodes())
		{
			node.removeChild(node.lastChild);
		}
		
		//remove the node itself
		node.parentNode.removeChild(node);
		
		list_count --;
	}
	
	
}

function removeCalendar()
{
	var node;
	
	//check to see that the element to be removed exists
	if((node = document.getElementById("cal-listcontainer" + this.id)) != null)
	{
		//remove all the node's children
		while(node.hasChildNodes())
		{
			node.removeChild(node.lastChild);
		}
		
		//remove the node itself
		node.parentNode.removeChild(node);
		
	}
	
}

function removeEventDisplay(){
	var node;
	
	//check to see that the element to be removed exists
	if((node = document.getElementById("event-display" + this.id)) != null)
	{
		//remove all the node's children
		while(node.hasChildNodes())
		{
			node.removeChild(node.lastChild);
		}
		
		//remove the node itself
		node.parentNode.removeChild(node);
	}
}

function removeWeeklyCalendar()
{
	var node;
	
	//check to see that the element to be removed exists
	if((node = document.getElementById("weeklycontainer" + this.id)) != null)
	{
		//remove all the node's children
		while(node.hasChildNodes())
		{
			node.removeChild(node.lastChild);
		}
		
		//remove the node itself
		node.parentNode.removeChild(node);
		
	}
	
}

function addListItem()
{
	var list_id = this.id;
	
	var dash = document.getElementById("dashboard");
	
	var add_container = document.createElement("div");
	add_container.setAttribute("id", "addWindow");
	add_container.setAttribute("class", "list-display");
	
	dash.appendChild(add_container);
	
	var title = document.createElement("p");
	title.innerHTML = "Add A List Item";
	
	var add_form = document.createElement("form");
	add_form.setAttribute("action", "src/logic/addListItem.php");
	add_form.setAttribute("method", "post");
	
	var item_label = document.createElement("label");
	var item_text = document.createTextNode("Item Description: ");
	var item_input = document.createElement("input");
	item_input.type = "text";
	item_input.name = "item_add";
	
	var id_pass = document.createElement("input");
	id_pass.type = "hidden";
	id_pass.name = "list_id";
	id_pass.value = list_id;
	
	var br = document.createElement("br");
	
	var add_submit = document.createElement("input");
	add_submit.type = "submit";
	add_submit.value = "Add Item";
	add_submit.setAttribute("class", "toolbtn");
	
	var cancel = document.createElement("button");
	cancel.innerHTML = "Cancel";
	cancel.addEventListener("click", removeWindow);
	cancel.setAttribute("class", "toolbtn");
	
	add_container.appendChild(title);
	
	item_label.appendChild(item_text);
	item_label.appendChild(item_input);
	
	add_form.appendChild(item_label);
	add_form.appendChild(id_pass);
	add_form.appendChild(br);
	add_form.appendChild(add_submit);
	
	add_container.appendChild(add_form);
	add_container.appendChild(cancel);
}

function addList()
{
	var dash = document.getElementById("dashboard");
	
	var add_container = document.createElement("div");
	add_container.setAttribute("id", "addWindow");
	add_container.setAttribute("class", "list-display");
	
	dash.appendChild(add_container);
	
	var title = document.createElement("p");
	title.innerHTML = "Add A List";
	
	var add_form = document.createElement("form");
	add_form.setAttribute("action", "src/logic/addList.php");
	add_form.setAttribute("method", "post");
	
	var name_label = document.createElement("label");
	var name_text = document.createTextNode("List Name: ");
	var name_input = document.createElement("input");
	name_input.type = "text";
	name_input.name = "list_name";
	
	var desc_label = document.createElement("label");
	var desc_text = document.createTextNode("Description: ");
	var desc_input = document.createElement("input");
	desc_input.type = "text";
	desc_input.name = "listDesc";
	
	var id_pass = document.createElement("input");
	id_pass.type = "hidden";
	id_pass.name = "userid";
	id_pass.value = user[0];
	
	var br = document.createElement("br");
	
	var add_submit = document.createElement("input");
	add_submit.type = "submit";
	add_submit.value = "Add List";
	add_submit.setAttribute("class", "toolbtn");
	
	var cancel = document.createElement("button");
	cancel.innerHTML = "Cancel";
	cancel.addEventListener("click", removeWindow);
	cancel.setAttribute("class", "toolbtn");
	
	add_container.appendChild(title);
	
	name_label.appendChild(name_text);
	name_label.appendChild(name_input);
	
	desc_label.appendChild(desc_text);
	desc_label.appendChild(desc_input);
	
	add_form.appendChild(name_label);
	add_form.appendChild(br);
	add_form.appendChild(desc_label);
	add_form.appendChild(id_pass);
	br = document.createElement('br');
	add_form.appendChild(br);
	add_form.appendChild(add_submit);
	
	add_container.appendChild(add_form);
	add_container.appendChild(cancel);
}

function addCalendar()
{
	var dash = document.getElementById("dashboard");
	
	var add_container = document.createElement("div");
	add_container.setAttribute("id", "addWindow");
	add_container.setAttribute("class", "list-display");
	
	dash.appendChild(add_container);
	
	var title = document.createElement("p");
	title.innerHTML = "Add A Calendar";
	
	var add_form = document.createElement("form");
	add_form.setAttribute("action", "src/logic/addCalendar.php");
	add_form.setAttribute("method", "post");
	
	var name_label = document.createElement("label");
	var name_text = document.createTextNode("Calendar Name: ");
	var name_input = document.createElement("input");
	name_input.type = "text";
	name_input.name = "calendar_name";
	
	var id_pass = document.createElement("input");
	id_pass.type = "hidden";
	id_pass.name = "userid";
	id_pass.value = user[0];
	
	var br = document.createElement("br");
	
	var add_submit = document.createElement("input");
	add_submit.type = "submit";
	add_submit.value = "Add Calendar";
	add_submit.setAttribute("class", "toolbtn");
	
	var cancel = document.createElement("button");
	cancel.innerHTML = "Cancel";
	cancel.addEventListener("click", removeWindow);
	cancel.setAttribute("class", "toolbtn");
	
	add_container.appendChild(title);
	
	name_label.appendChild(name_text);
	name_label.appendChild(name_input);
	
	add_form.appendChild(name_label);
	add_form.appendChild(br);
	add_form.appendChild(id_pass);
	br = document.createElement('br');
	add_form.appendChild(br);
	add_form.appendChild(add_submit);
	
	add_container.appendChild(add_form);
	add_container.appendChild(cancel);
}//addCalendar

function addCalendarItem()
{
	var dash = document.getElementById("dashboard");
	
	var add_container = document.createElement("div");
	add_container.setAttribute("id", "addWindow");
	add_container.setAttribute("class", "list-display");
	
	dash.appendChild(add_container);
	
	var title = document.createElement("p");
	title.innerHTML = "Add A Calendar Item";
	
	var add_form = document.createElement("form");
	add_form.setAttribute("action", "src/logic/addCalendarItem.php");
	add_form.setAttribute("method", "post");
	
	var name_label = document.createElement("label");
	var name_text = document.createTextNode("Event Name: ");
	var name_input = document.createElement("input");
	name_input.type = "text";
	name_input.name = "event_name";
	
	var desc_label = document.createElement("label");
	var desc_text = document.createTextNode("Description: ");
	var desc_input = document.createElement("input");
	desc_input.type = "text";
	desc_input.name = "event_desc";
	
	var loc_label = document.createElement("label");
	var loc_text = document.createTextNode("Location: ");
	var loc_input = document.createElement("input");
	loc_input.type = "text";
	loc_input.name = "event_loc";
	
	var time_label = document.createElement("label");
	var time_text = document.createTextNode("Time: ");
	var time_input = document.createElement("input");
	//time_input.pattern = "[0-9]{4}+-[0-9]{2}+-[0-9]+\s+[0-9]{2}+:[0-9]{2}+:[0-9]{2}";
	time_input.type = "text";
	time_input.name = "event_time";
	
	var id_pass = document.createElement("input");
	id_pass.type = "hidden";
	id_pass.name = "calendarid";
	id_pass.value = this.id;
	
	var br = document.createElement("br");
	
	var add_submit = document.createElement("input");
	add_submit.type = "submit";
	add_submit.value = "Add Event";
	add_submit.setAttribute("class", "toolbtn");
	
	var cancel = document.createElement("button");
	cancel.innerHTML = "Cancel";
	cancel.addEventListener("click", removeWindow);
	cancel.setAttribute("class", "toolbtn");
	
	add_container.appendChild(title);
	
	name_label.appendChild(name_text);
	name_label.appendChild(name_input);
	
	desc_label.appendChild(desc_text);
	desc_label.appendChild(desc_input);
	
	loc_label.appendChild(loc_text);
	loc_label.appendChild(loc_input);
	
	time_label.appendChild(time_text);
	time_label.appendChild(time_input);
	
	add_form.appendChild(name_label);
	add_form.appendChild(br);
	add_form.appendChild(desc_label);
	br = document.createElement('br');
	add_form.appendChild(br);
	add_form.appendChild(loc_label);
	br = document.createElement('br');
	add_form.appendChild(br);
	add_form.appendChild(time_label);
	add_form.appendChild(id_pass);
	br = document.createElement('br');
	add_form.appendChild(br);
	add_form.appendChild(add_submit);
	
	add_container.appendChild(add_form);
	add_container.appendChild(cancel);
}

function updateCalendarItem()
{
	//the event id
	var id = this.getAttribute("id");
	
	//the calendar id
	var calendarid = this.getAttribute("name");
	
	var cur_event;
	for(var i = 0; i < calendar_item_array.length; i++)
	{
		if(calendar_item_array[i].getId() == id)
		{
			cur_event = calendar_item_array[i];
			break;
		}
	}
	
	var dash = document.getElementById("dashboard");
	
	var add_container = document.createElement("div");
	add_container.setAttribute("id", "addWindow");
	add_container.setAttribute("class", "list-display");
	
	dash.appendChild(add_container);
	
	var title = document.createElement("p");
	title.innerHTML = "Edit a Calendar Item";
	
	var add_form = document.createElement("form");
	add_form.setAttribute("action", "src/logic/updateCalendarItem.php");
	add_form.setAttribute("method", "post");
	
	var name_label = document.createElement("label");
	var name_text = document.createTextNode("Event Name: ");
	var name_input = document.createElement("input");
	name_input.type = "text";
	name_input.value = cur_event.getName();
	name_input.name = "event_name";
	
	var desc_label = document.createElement("label");
	var desc_text = document.createTextNode("Description: ");
	var desc_input = document.createElement("input");
	desc_input.type = "text";
	desc_input.value = cur_event.getDescription();
	desc_input.name = "event_desc";
	
	var loc_label = document.createElement("label");
	var loc_text = document.createTextNode("Location: ");
	var loc_input = document.createElement("input");
	loc_input.type = "text";
	loc_input.value = cur_event.getLocation();
	loc_input.name = "event_loc";
	
	var time_label = document.createElement("label");
	var time_text = document.createTextNode("Time: ");
	var time_input = document.createElement("input");
	//time_input.pattern = "[0-9]{4}+-[0-9]{2}+-[0-9]+\s+[0-9]{2}+:[0-9]{2}+:[0-9]{2}";
	time_input.type = "text";
	time_input.value = cur_event.getTime();
	time_input.name = "event_time";
	
	var id_pass = document.createElement("input");
	id_pass.type = "hidden";
	id_pass.name = "id";
	id_pass.value = id;
	
	var cal_id_pass = document.createElement("input");
	cal_id_pass.type = "hidden";
	cal_id_pass.name = "calendarid";
	cal_id_pass.value = calendarid;
	
	var br = document.createElement("br");
	
	var add_submit = document.createElement("input");
	add_submit.type = "submit";
	add_submit.value = "Update";
	add_submit.setAttribute("class", "toolbtn");
	
	var cancel = document.createElement("button");
	cancel.innerHTML = "Cancel";
	cancel.addEventListener("click", removeWindow);
	cancel.setAttribute("class", "toolbtn");
	
	add_container.appendChild(title);
	
	name_label.appendChild(name_text);
	name_label.appendChild(name_input);
	
	desc_label.appendChild(desc_text);
	desc_label.appendChild(desc_input);
	
	loc_label.appendChild(loc_text);
	loc_label.appendChild(loc_input);
	
	time_label.appendChild(time_text);
	time_label.appendChild(time_input);
	
	add_form.appendChild(name_label);
	add_form.appendChild(br);
	add_form.appendChild(desc_label);
	br = document.createElement('br');
	add_form.appendChild(br);
	add_form.appendChild(loc_label);
	br = document.createElement('br');
	add_form.appendChild(br);
	add_form.appendChild(time_label);
	add_form.appendChild(id_pass);
	add_form.appendChild(cal_id_pass);
	br = document.createElement('br');
	add_form.appendChild(br);
	add_form.appendChild(add_submit);
	
	add_container.appendChild(add_form);
	add_container.appendChild(cancel);
}

function removeWindow()
{
	
	var node;
	
	//check to see that the element to be removed exists
	if((node = document.getElementById("addWindow")) != null)
	{
		//remove all the node's children
		while(node.hasChildNodes())
		{
			node.removeChild(node.lastChild);
		}
		
		//remove the node itself
		node.parentNode.removeChild(node);
		
	}
	
}

//Functions to specify drag behavior
function allowDrop(ev)
{
	ev.preventDefault();
}

function drag(ev)
{
	ev.dataTransfer.setData("text", ev.target.id);
	
	var x_elem = 0, y_elem = 0;
	
	x_elem = ev.pageX - ev.target.offsetLeft;
	y_elem = ev.pageY - ev.target.offsetTop;
	
	ev.dataTransfer.setData("x_elem", x_elem);
	ev.dataTransfer.setData("y_elem", y_elem);
}

function drop(ev)
{
	ev.preventDefault();
	var data = ev.dataTransfer.getData("text");
	var elem = document.getElementById(data);
	var x_elem = ev.dataTransfer.getData("x_elem");
	var y_elem = ev.dataTransfer.getData("y_elem");
	elem.style.left = (ev.pageX - x_elem) + 'px';
	elem.style.top = (ev.pageY - y_elem) + 'px';
	ev.target.appendChild(elem);
}

window.onclick = function(event) 
{
	if(!event.target.matches('.toolbtn')) 
	{
		var dropmenus = document.getElementsByClassName("menu-item");
		for(var i = 0; i < dropmenus.length; i++)
		{
			var openMenu = dropmenus[i];
			if(openMenu.classList.contains('show'))
			{
				openMenu.classList.remove('show');
			}
		}
	}
}
