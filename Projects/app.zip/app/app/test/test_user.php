<?php

require '../src/obj/user.php'; //Windows
//require '/home/chase/public_html/app/src/obj/user.php';	//Linux

$username = $password = $first = $last = '';

$username = 'macklyback';
$password = 'pass';
$first = 'John';
$last = 'Smith';

$obj = new User($username, $password, $first, $last);

echo '<h1>' . $obj->getUsername() . '</h1><br>';
echo '<h1>' . $obj->getPassword() . '</h1><br>';
echo '<h1>' . $obj->getFirst() . '</h1><br>';
echo '<h1>' . $obj->getLast() . '</h1><br>';

?>
