<?php

$win_path = 'C:\xampp\htdocs\app\\';
$lin_path = 'home/chase/public_html/app/';
set_include_path(get_include_path() . PATH_SEPARATOR . $win_path . PATH_SEPARATOR . $lin_path);


require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'calendar.php'; //Windows
require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'calendarItem.php'; //Windows
require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'list.php'; //Windows
require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'listItem.php'; //Windows
require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'user.php'; //Windows
require_once 'src' . DIRECTORY_SEPARATOR . 'layer' . DIRECTORY_SEPARATOR . 'PersistenceLayer.php';

//create and check connection
$conn = new mysqli('localhost', 'app', 'app', 'app');

if($conn->connect_error)
{
	die("Connection Failed: " . $conn->connect_error);
}

//Create a PersistenceLayer with our connection
$pLayer = new PersistenceLayer($conn);

//Use our Persistence Layer to query the database for a user
$username = 'superman';
$password = 'superpassword';

$newUser = $pLayer->restoreUser($username, $password);

if(gettype($newUser) == 'integer')
{
	if($newUser == -1) echo 'no users found.';
	else if($newUser == -2) echo 'unexpected error.';
}
else
{
	echo $newUser->getId() . '<br>';
	echo $newUser->getUsername() . '<br>';
	echo $newUser->getPassword() . '<br>';
	echo $newUser->getFirst() . '<br>';
	echo $newUser->getLast() . '<br>';
	echo '<br>';
}

//query for calendars
$calendarArray = $pLayer->restoreCalendar($newUser);
$length = count($calendarArray);

echo "Calendars: <br>";
for($i = 0; $i < $length; $i++)
{
	echo $calendarArray[$i]->getId() . ", ";
	echo $calendarArray[$i]->getUserid() . ", ";
	echo $calendarArray[$i]->getName() . ", ";
	echo $calendarArray[$i]->getVisible();

	echo '<br>';
}

//create a calendar
$newCalendar = new Calendar($newUser->getId(), 'stuff', 1);
$newCalendar->setId($pLayer->createCalendar($newUser, $newCalendar));

echo $newCalendar->getId() . ', ' . $newCalendar->getUserid() . ', ' . $newCalendar->getName();
echo ', ' . $newCalendar->getVisible() . '<br>';

echo '<br>';

//test a calendar update
$newCalendar->setVisible(0);

if($pLayer->updateCalendar($newCalendar) == 0) 
{
	echo 'Calendar updated successfully. <br>';
	echo 'new visibility: ' . $newCalendar->getVisible() . '<br>';
}
else echo 'Calendar update failed. <br>';

//test a calendar delete
if($pLayer->deleteCalendar($newCalendar) == 0) echo 'Calendar deleted successfully. <br>';
else echo 'Calendar delete failed. <br>';

//test calendarItem stuff
$calendarItemArray = $pLayer->restoreCalendarItem($calendarArray[0]);
$length = count($calendarItemArray);

echo 'Events on ' . $newUser->getFirst() . '\'s calendar \'' . $calendarArray[0]->getName() . '\': <br>';
for($i = 0; $i < $length; $i++)
{
	echo $calendarItemArray[$i]->getId() . ', ';
	echo $calendarItemArray[$i]->getCalendarId() . ', ';
	echo $calendarItemArray[$i]->getName() . ', ';
	echo $calendarItemArray[$i]->getDescription() . ', ';
	echo $calendarItemArray[$i]->getLocation() . ', ';
	echo $calendarItemArray[$i]->getTime() . '<br>';
}

//add a calendarItem
$newCalendarItem = new CalendarItem(
	$calendarArray[0]->getId(),
	'Fight Batman',
	'Batman is a douche and he thinks he can beat me, lolz',
	'Metropolis',
	'2017-05-24 22:25:00'
);

$newCalendarItem->setId($pLayer->createCalendarItem($newCalendarItem));

echo 'Added Event: ' . 
	$newCalendarItem->getId() . ', ' .
	$newCalendarItem->getCalendarId() . ', ' .
	$newCalendarItem->getName() . ', ' .
	$newCalendarItem->getDescription() . ', ' .
	$newCalendarItem->getLocation() . ', ' .
	$newCalendarItem->getTime() . '<br>';

//Delete the calendarItem
$newCalendarItem = $pLayer->deleteCalendarItem($newCalendarItem);
if($newCalendarItem == 0) echo 'Event deleted successfully. <br>';

$conn->close();

?>
