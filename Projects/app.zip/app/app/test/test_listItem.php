<?php

require '../src/obj/listItem.php'; //Windows
//require '/home/chase/public_html/app/src/obj/listItem.php'; //Linux

$listid = 13;
$description = 'Cook a rat';

$obj = new ListItem($listid, $description);

echo '<h1>' . $obj->getListid() . '</h1><br>';
echo '<h1>' . $obj->getDescription() . '</h1><br>';

?>
