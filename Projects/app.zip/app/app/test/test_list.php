<?php

require '../src/obj/list.php'; //Windows
//require '/home/chase/public_html/app/src/obj/list.php';	//Linux

$userid = 21;
$name = 'Today\'s List';
$description = 'Stuff I need to get done today.';

$obj = new UserList($userid, $name, $description);

echo '<h1>' . $obj->getUserid() . '</h1><br>';
echo '<h1>' . $obj->getName() . '</h1><br>';
echo '<h1>' . $obj->getDescription() . '</h1><br>';

?>
