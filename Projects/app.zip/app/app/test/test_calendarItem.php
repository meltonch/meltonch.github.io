<?php

require '../src/obj/calendarItem.php'; //Windows
//require '/home/chase/public_html/app/src/obj/calendarItem.php';	//Linux

$calendarid = 2;
$name = "John's Birthday";
$description = "John's birthday is today. Remember to say something about it!";
$location = "1234 Streety Street Place, Statesville, State 30000";
$time = '03:05:15 12:30:00'; 

$obj = new CalendarItem($calendarid, $name, $description, $location, $time);

echo '<h1>' . $obj->getCalendarid() . '</h1><br>';
echo '<h1>' . $obj->getName() . '</h1><br>';
echo '<h1>' . $obj->getDescription() . '</h1><br>';
echo '<h1>' . $obj->getLocation() . '</h1><br>';
echo '<h1>' . $obj->getTime() . '</h1><br>';

?>
