<?php

$path = 'C:\xampp\htdocs\app\\';
set_include_path(get_include_path() . PATH_SEPARATOR . $path);

//include calendar object
require_once 'src\obj\calendar.php';
//require '/home/chase/public_html/app/src/obj/calendar.php';	//Linux

$userid = 3;
$name = "Fun Stuff";
$visible = true;

$obj = new Calendar($userid, $name, $visible);

echo '<h1>' . $obj->getUserid() . '</h1><br>';
echo '<h1>' . $obj->getName() . '</h1><br>';

if($obj->getVisible()) echo '<h1>TRUE</h1><br>';
else echo '<h1>FALSE</h1><br>';

?>
