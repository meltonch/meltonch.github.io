<?php

$win_path = 'C:\xampp\htdocs\app\\';
$lin_path = 'home/chase/public_html/app/';
set_include_path(get_include_path() . PATH_SEPARATOR . $win_path . PATH_SEPARATOR . $lin_path);

require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'user.php';
require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'calendar.php';
require_once 'src' . DIRECTORY_SEPARATOR . 'layer' . DIRECTORY_SEPARATOR . 'PersistenceLayer.php';


session_start();

if(!isset($_SESSION['user']))
{
	header("Location: http://localhost/app/no_signin.html");
	exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Your schedule page</title>
    <link rel="stylesheet" href="stylesheet.css" />
	<script type="text/javascript" src="http://localhost/app/src/javascript/main.js"></script>
    <script type="text/javascript" src="http://localhost/app/src/obj/calendar.js"></script>
    <script type="text/javascript" src="http://localhost/app/src/obj/UserList.js"></script>
    <script type="text/javascript" src="http://localhost/app/src/obj/CalendarItem.js"></script>
    <script type="text/javascript" src="http://localhost/app/src/obj/ListItem.js"></script>
</head>
<body> 
    <div class="container">
		<div class="greetdate">
			<h1 id="name">Hello, David</h1>
			<p id="date" class="date">
				Today is Thursday, March 14, 2016. | 
				<a href="http://localhost/app/src/logic/signout.php">Sign Out</a>
			</p>
			<div class="weather">
				<p class="weatherrep">
					<span id="curr">Currently </span>
					<span id="currTemp"></span>
					&deg;
					<img id="weathericon" src= "" alt="" height=50 width=50/>
				</p>
				<p id="location"></p>
			</div><!--weather-->
		</div><!--greetdate-->
		<div id="dashboard" ondrop="drop(event)" ondragover="allowDrop(event)">
			<div id="toolbar">

				<div id="calendar-menu" class="menu-parent">
					<button onclick="listCalendars()" class="toolbtn">Calendars</button>
					<div id="calendar-content" class="menu-item">
						<div id="calendar-add">Add New...</div>
					</div><!--Calendar content-->			
				</div><!--calendar dropmenu-->

				<div id="list-menu" class="menu-parent">
					<button onclick="listLists()" class="toolbtn">Lists</button>
					<div id="list-content" class="menu-item">
						<div id="list-add">Add New...</div>
					</div><!--list content-->			
				</div><!--list dropmenu-->

		</div><!--dashboard-->
    </div><!--container-->

    <div id="dom-target"><!--This is where we will place information retrieved by the database
	so that we can access it with javascript via DOM operations.-->
	<?php

		//create and check connection
		$conn = new mysqli('localhost', 'app', 'app', 'app');

		if($conn->connect_error)
		{
			die("Connection Failed: " . $conn->connect_error);
		}

		//Create a PersistenceLayer with our connection
		$pLayer = new PersistenceLayer($conn);
	
		//create a paragraph element to hold user data. ID will be referenced by javascript.
		echo '<p id="u">' . json_encode($_SESSION['user']) . '</p></br>';
		
		$data = $_SESSION['user'];
		$cur_user = $pLayer->restoreUser($data[1], $data[2]);
	
		//check for calendars and lists
		$calendars = $pLayer->restoreCalendar($cur_user);
		$lists = $pLayer->restoreUserList($cur_user);
		
		$cal_size = count($calendars);
		$list_size = count($lists);		
		
		//echo each calendar as a paragraph element
		if($calendars != -1)
		{
			for($i = 0; $i < $cal_size; $i++)
			{
				$cur_cal = array(
					$calendars[$i]->getId(),
					$calendars[$i]->getUserid(),
					$calendars[$i]->getName(),
					$calendars[$i]->getVisible()
				);
			
				echo '<p id="c' . $i . '">' . json_encode($cur_cal) . '</p></br>';		
			}
		}
		
		//echo calendarItems as paragraph elements
		for($i = 0; $i < $cal_size; $i++)
		{
			$calendar_items = $pLayer->restoreCalendarItem($calendars[$i]);
			$item_count = count($calendar_items);
			
			if($calendar_items != -1)
			{
				for($j = 0; $j < $item_count; $j++)
				{	
					$cur_cal_item = array(
						$calendar_items[$j]->getId(),
						$calendar_items[$j]->getCalendarid(),
						$calendar_items[$j]->getName(),
						$calendar_items[$j]->getDescription(),
						$calendar_items[$j]->getLocation(),
						$calendar_items[$j]->getTime()
					);
					
					//ci, for calendarItem, plus the calendar id, plus the inner loop index
					echo '<p id="ci' . $calendar_items[$j]->getCalendarid() . $j . '">' . json_encode($cur_cal_item) . '</p></br>';
				}
			}
			
		}
		
		//echo each list as a paragraph element
		if($lists != -1)
		{
			for($i = 0; $i < $list_size; $i++)
			{
				$cur_list = array(
					$lists[$i]->getId(),
					$lists[$i]->getUserid(),
					$lists[$i]->getName(),
					$lists[$i]->getDescription()
				);
			
				echo '<p id="l' . $i . '">' . json_encode($cur_list) . '</p></br>';		
			}
		}
		
		//echo ListItems as paragraph elements
		for($i = 0; $i < $list_size; $i++)
		{
			$list_items = $pLayer->restoreListItem($lists[$i]);
			$item_count = count($list_items);
			
			if($list_items != -1)
			{
				for($j = 0; $j < $item_count; $j++)
				{	
					$cur_list_item = array(
						$list_items[$j]->getId(),
						$list_items[$j]->getListid(),
						$list_items[$j]->getDescription()			
					);
					
					echo '<p id="li' . $list_items[$j]->getListid() . $j . '">' . json_encode($cur_list_item) . '</p></br>';
				}
			}
			
		}
		
		$conn->close();
		
	?>
    </div>
</body>
</html>
