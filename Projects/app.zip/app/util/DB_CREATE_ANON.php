<?php

//This information assumes your MySQL server is running locally. 
//If not, you need to change "localhost" to the address of the server.
//Also, username and password need to be changed to account 
//credentials that have permissions to do these things.
$servername = "127.0.0.1";
$username = "app";
$password = "app";
$dbname = "app";

//Connect to Database
$conn = new mysqli($servername, $username, $password);

//check connection
if($conn->connect_error)
{
	die("Connection failed: " . $conn->connect_error);
}

//create database
$sql = "create database app";
if($conn->query($sql) === TRUE)
{
	echo "Database Created Successfully.";
}
else
{
	echo "Error creating database: " . $conn->error;
}

echo "<br>";

$conn->close();

//Reconnect, adding the database as a parameter
$conn = new mysqli($servername, $username, $password, $dbname);

//check connection again
if($conn->connect_error)
{
	die("Connection Failed: " . $conn->connect_error);
}

//create tables
$sql = "create table user (
id int(6) unsigned auto_increment primary key,
username varchar(20) not null,
password varchar(20) not null,
first varchar(20),
last varchar(20)
)";

if($conn->query($sql) === TRUE)
{
	echo "User Created Successfully.";
}
else
{
	echo "Error creating User: " . $conn->error;
}

echo "<br>";

$sql = "create table calendar (
id int(6) unsigned auto_increment primary key,
userid int(6),
name varchar(20) not null,
visible bool
)";

if($conn->query($sql) === TRUE)
{
	echo "Calendar Created Successfully.";
}
else
{
	echo "Error creating Calendar: " . $conn->error;
}

echo "<br>";

$sql = "create table calendaritem (
id int(6) unsigned auto_increment primary key,
calendarid int(6),
name varchar(50),
description varchar(256),
location varchar(50),
time datetime
)";

if($conn->query($sql) === TRUE)
{
	echo "Calendar Item Created Successfully.";
}
else
{
	echo "Error creating Calendar Item: " . $conn->error;
}

echo "<br>";

$sql = "create table list (
id int(6) unsigned auto_increment primary key,
userid int(6),
name varchar(256),
description varchar(256)
)";

if($conn->query($sql) === TRUE)
{
	echo "List Created Successfully.";
}
else
{
	echo "Error creating List: " . $conn->error;
}

echo "<br>";

$sql = "create table listitem (
id int(6) unsigned auto_increment primary key,
listid int(6),
description varchar(256)
)";

if($conn->query($sql) === TRUE)
{
	echo "List Item Created Successfully.";
}
else
{
	echo "Error creating List Item: " . $conn->error;
}

echo "<br>";

//Add duplicate rules to ensure duplicate entries are not added
//to tables based on the following criteria
$sql = "alter ignore table user
add unique index(username)";

if($conn->query($sql) === TRUE)
{
	echo "User duplicate rule created successfully.";
}
else
{
	echo "Error: " . $conn->error;
}

echo "<br>";

$sql = "alter ignore table calendar
add unique index(userid, name)";

if($conn->query($sql) === TRUE)
{
	echo "Calendar duplicate rule created successfully.";
}
else
{
	echo "Error: " . $conn->error;
}

echo "<br>";

$sql = "alter ignore table calendaritem
add unique index(calendarid, name, description, location, time)";

if($conn->query($sql) === TRUE)
{
	echo "calendaritem duplicate rule created successfully.";
}
else
{
	echo "Error: " . $conn->error;
}

echo "<br>";

$sql = "alter ignore table list
add unique index(userid, name)";

if($conn->query($sql) === TRUE)
{
	echo "list duplicate rule created successfully.";
}
else
{
	echo "Error: " . $conn->error;
}

echo "<br>";

//Add test data to tables
$sql = "insert into user (username, password, first, last)
VALUES('superman', 'superpassword', 'Clarke', 'Kent'),
('batman', 'batpass', 'Bruce', 'Wayne')";

if($conn->query($sql) === TRUE)
{
	echo "New User created successfully.";
}
else
{
	echo "Error: " . $conn->error;
}

echo "<br>";

$sql = "insert into calendar (userid, name, visible)
VALUES(1, 'Crime Calendar', 1),
(1, 'Planet Schedule', 1),
(2, 'Bat Calendar', 1)";

if($conn->query($sql) === TRUE)
{
	echo "New Calendar created successfully.";
}
else
{
	echo "Error: " . $conn->error;
}

echo "<br>";

$sql = "insert into calendaritem(calendarid, name, description, location, time)
VALUES(1, 'Lex Hex', 'Lex Luthor is throwing a party, and he needs to be stopped.', 'City Center', '2016-05-01 19:30:00'),
(1, 'World Invasion', 'The world is being invaded and I must stop it.', 'Planet Earth', '2016-05-04 15:15:00'),
(1, 'Fight Batman', 'This is literally a joke I can\'t even', 'Gotham I guess?', '2016-05-05 20:15:00'),
(2, 'Article Ideas', 'Come up with ideas for the paper this week.', 'Daily Planet', '2016-05-02 08:00:00'),
(2, 'Drafts Due', 'Article Drafts due by 5', 'Daily Planet', '2016-05-04 08:00:00'),
(2, 'Paper Release', 'The planet gets released today.', 'Daily Planet', '2016-05-06 06:00:00'),
(2, 'Paper Release', 'The planet gets released today.', 'Daily Planet', '2016-05-13 06:00:00'),
(2, 'Paper Release', 'The planet gets released today.', 'Daily Planet', '2016-05-20 06:00:00'),
(2, 'Paper Release', 'The planet gets released today.', 'Daily Planet', '2016-05-27 06:00:00'),
(3, 'Stalk People', 'Night falls and I must break out the batsuit.', 'Gotham Plaza', '2016-07-23 20:20:00')";

if($conn->query($sql) === TRUE)
{
	echo "New Calendar Item created successfully.";
}
else
{
	echo "Error: " . $conn->error;
}

echo "<br>";

$sql = "insert into list(userid, name, description)
values(1, 'Criminal List', 'A place to keep track of my criminals.'),
(1, 'Planet Tasks', 'A place to keep up with my Daily Planet work.'),
(2, 'Bat Tasks', 'A place to keep up with my Bat Tasks.')";

if($conn->query($sql) === TRUE)
{
	echo "New List created successfully.";
}
else
{
	echo "Error: " . $conn->error;
}

echo "<br>";

$sql = "insert into listitem(listid, description)
values(1, 'Lex Luthor'),
(1, 'General Zod'),
(1, 'Batman, I guess?'),
(2, 'Write Articles'),
(2, 'Take photots'),
(2, 'Get Editor Approval'),
(2, 'Interview City Folk'),
(2, 'Don\'t Accidentally Reveal Identity'),
(3, 'Clean the Batcave'),
(3, 'Sleep'),
(3, 'Be Mopey')";

if($conn->query($sql) === TRUE)
{
	echo "New List Item created successfully.";
}
else
{
	echo "Error: " . $conn->error;
}

echo "<br>";


//close connection
$conn->close();

?>
