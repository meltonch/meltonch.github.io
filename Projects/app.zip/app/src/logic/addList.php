<?php

$win2_path = 'E:\Program Files E\XAMPP\htdocs\app\\';
$win_path = 'C:\xampp\htdocs\app\\';
$lin_path = 'home/chase/public_html/app/';
set_include_path(get_include_path() . PATH_SEPARATOR . $win_path . PATH_SEPARATOR . $win2_path . PATH_SEPARATOR . $lin_path);

require_once 'src' . DIRECTORY_SEPARATOR . 'obj' . DIRECTORY_SEPARATOR . 'list.php'; 
require_once 'src' . DIRECTORY_SEPARATOR . 'layer' . DIRECTORY_SEPARATOR . 'PersistenceLayer.php';

//create and check connection
$conn = new mysqli('localhost', 'app', 'app', 'app');

if($conn->connect_error)
{
	die("Connection Failed: " . $conn->connect_error);
}

//Create a PersistenceLayer with our connection
$pLayer = new PersistenceLayer($conn);

//get list item info via post
if(
	isset($_POST['userid']) &&
	isset($_POST['list_name']) &&
	isset($_POST['listDesc'])
)
{
	$userList = new UserList(
		$_POST['userid'],
		$_POST['list_name'],
		$_POST['listDesc']
	);
}
else
{
	header("Location: http://localhost/app/main.php");
	$conn->close();
	exit();
}

$result = $pLayer->createUserList($userList);

if(gettype($result) == 'integer')
{
	header("Location: http://localhost/app/main.php");
}
else
{
	echo "Something Broke! Oh Noes!!!!!";
}

$conn->close();

?>